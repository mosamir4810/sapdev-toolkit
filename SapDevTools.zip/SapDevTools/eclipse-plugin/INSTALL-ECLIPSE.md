# ARC-1 Eclipse plugin (com.arc1.mcp 0.6.2) - install guide

This jar adds extra tools to SAP's own MCP server inside Eclipse/ADT, so `sapdev` (via `"via": "eclipse"`) and MCP clients such as Claude Code can use Eclipse's already-logged-on ABAP project. That also reaches systems that block direct HTTPS access to `/sap/bc/adt`.

- Based on the open-source project github.com/arc-mcp/arc1-adt-abap-mcp-ext (MIT, see `LICENSE`, upstream v0.5.1).
- This build is 0.6.2: upstream plus two extra write tools (`arc1_sap_write_source`, `arc1_sap_delete_object`) and a JSON parser fix. See `source/LOCAL-CHANGES.md`.

## Requirements
- Eclipse with **ABAP Development Tools 3.60 or newer** (the jar requires `com.sap.adt.*` bundles in version range [3.60, 4.0)). Check: Help > About Eclipse > Installation Details.
- The Eclipse JVM must be Java 21 or newer (modern ADT Eclipse builds are).
- An ABAP project for each system, logged on.

## Install (you do the clicks; close Eclipse fully before step 3)
1. Enable SAP's MCP server: add `-DadtMcpServerPrefEnabled=true` as the LAST line of `<eclipse>\eclipse.ini` (make a `.bak` copy first). Skip if the preference page below already exists.
2. Copy `com.arc1.mcp_0.6.2.jar` into `<eclipse>\dropins\` (or run `node sapdev.js eclipse-plugin install "<eclipse folder>" --confirm`).
3. Close Eclipse completely (no `eclipse.exe` process left; two overlapping instances stop the tools from registering), then start it once with the `-clean` option: `eclipse.exe -clean`. If an Eclipse Update (Oomph) dialog appears, click Skip.
4. In Eclipse: Window > Preferences > ABAP Development > MCP Server: tick Enable, keep port 2234, click Generate for a token, Apply. Copy the token into an environment variable, not into chat or files (`setx ECLIPSE_MCP_TOKEN "<token>"`, then open a new terminal).
5. Log on to your ABAP project(s).
6. Check: Window > Show View > Error Log should show "MCP Server started successfully on port 2234". From a terminal, `curl -i http://localhost:2234/mcp` answers 401 without a token.
7. `node sapdev.js add-system dev-eclipse --via eclipse --eclipse-token-env ECLIPSE_MCP_TOKEN --eclipse-project <ABAP project name>` then `node sapdev.js dev-eclipse doctor`.

Uninstall: close Eclipse, delete the jar from `dropins`, start once with `-clean`.

## Tools this plugin adds (all named arc1_sap_*)
Read: `search`, `repository_search`, `object_info`, `object_structure`, `object_types`, `find_definition`, `read_source`, `where_used`, `package_contents`, `list_projects`, `system_info`, `list_transports`, `list_inactive`, `check_syntax`, `run_unit_tests`, `atc_check`, `http_get`.
Write (guarded, see below): `http_post`, `write_source`, `delete_object`.

## Write guard (important)
`write_source` and `delete_object` refuse to work unless `~/.arc1/eclipse-write-allow.txt` allows the target. Copy `eclipse-write-allow.example.txt` there and edit it. `write_source` writes source into an object that exists already and does NOT activate it; create the object with SAP's own `abap_creation-create_object` first and activate afterwards with `abap_activate_objects`. `delete_object` only deletes local (`$TMP`) objects. Without that file, nothing can be written. Keep productive and payroll systems out of the allow list.

## Rebuild from source
`source/build-windows.ps1` (Windows, needs JDK 21 and the p2 plugin pool of your Eclipse) or `source/build.sh` (macOS, upstream). Tested: the Windows script reproduces the same 31 jar entries as the shipped jar.

```powershell
cd source
powershell -ExecutionPolicy Bypass -File .\build-windows.ps1 -Pool "<eclipse>\plugins"   # default pool: %USERPROFILE%\.p2\pool\plugins
```

## Known behaviour
- After every Eclipse restart you must log on to the ABAP project again, and MCP clients must reconnect (tools load at session start).
- Some systems expose no DDIC source over ADT (tables and structures return 404): read `DD02L`/`DD03L` with the SQL preview instead.
