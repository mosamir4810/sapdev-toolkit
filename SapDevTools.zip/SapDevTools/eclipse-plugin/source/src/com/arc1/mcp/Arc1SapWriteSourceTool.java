package com.arc1.mcp;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.runtime.NullProgressMonitor;

import com.sap.adt.communication.message.AdtRequestFactory;
import com.sap.adt.communication.message.ByteArrayMessageBody;
import com.sap.adt.communication.message.HeadersFactory;
import com.sap.adt.communication.message.IHeaders;
import com.sap.adt.communication.message.IMessageBody;
import com.sap.adt.communication.message.IRequest;
import com.sap.adt.communication.message.IResponse;
import com.sap.adt.communication.session.AdtSystemSessionFactory;
import com.sap.adt.communication.session.IStatefulSystemSession;
import com.sap.adt.mcp.core.AdtMcpToolCallResultBuilder;
import com.sap.adt.mcp.core.IAdtMCPTool;
import com.sap.adt.mcp.core.IAdtMcpToolCallResult;

/**
 * Writes the source of an existing ABAP object (program, include, function
 * module, class include ...) through Eclipse's own ADT session:
 * LOCK -> PUT source -> UNLOCK, all inside one stateful session.
 *
 * Guarded by an allow-list file (~/.arc1/eclipse-write-allow.txt) that is read
 * on every call, so it can be edited without restarting Eclipse. Lines:
 *   destination=<ABAP_PROJECT_DESTINATION>
 *   transport=<TRANSPORT_REQUEST>
 *   local=true            (optional: allow writes without transport, $TMP objects)
 * A call is refused unless its destination AND its transport are listed.
 * Activation is not done here: use abap_activate_objects afterwards.
 */
public class Arc1SapWriteSourceTool implements IAdtMCPTool {

    private static final Pattern LOCK_HANDLE =
        Pattern.compile("<LOCK_HANDLE>([^<]*)</LOCK_HANDLE>");

    @Override
    public String getName() {
        return "arc1_sap_write_source";
    }

    @Override
    public String getDescription() {
        return "Write (replace) the source of an existing ABAP object via ADT: lock, PUT, unlock. "
             + "Needs destination + sourceUri (e.g. /sap/bc/adt/programs/programs/ZX/source/main) "
             + "+ source text + transport. Refused unless destination and transport are in "
             + "~/.arc1/eclipse-write-allow.txt. Does NOT activate; call abap_activate_objects after.";
    }

    @Override
    public String getInputSchema() {
        return "{"
            + "\"type\":\"object\","
            + "\"properties\":{"
            +   "\"destination\":{\"type\":\"string\",\"description\":\"ADT destination ID\"},"
            +   "\"sourceUri\":{\"type\":\"string\","
            +     "\"description\":\"Source URI, ends with /source/main (or class include path)\"},"
            +   "\"source\":{\"type\":\"string\",\"description\":\"Complete new source text\"},"
            +   "\"transport\":{\"type\":\"string\",\"description\":\"Transport request, e.g. <TRANSPORT_REQUEST>\"}"
            + "},"
            + "\"required\":[\"destination\",\"sourceUri\",\"source\"]"
            + "}";
    }

    @Override
    public IAdtMcpToolCallResult execute(String jsonInput) {
        IStatefulSystemSession session = null;
        String lockUri = null;
        String handle = null;
        try {
            String destination = Json.readString(jsonInput, "destination");
            String sourceUri = Json.readString(jsonInput, "sourceUri");
            String source = Json.readString(jsonInput, "source");
            String transport = Json.readString(jsonInput, "transport");
            if (isEmpty(destination) || isEmpty(sourceUri) || source == null) {
                return error("Missing required field (destination, sourceUri, source)");
            }
            if (!sourceUri.startsWith("/sap/bc/adt/") || sourceUri.contains("?")) {
                return error("sourceUri must be a plain /sap/bc/adt/... path without query");
            }
            String denied = checkAllowList(destination, transport);
            if (denied != null) {
                return error("Write refused: " + denied);
            }

            lockUri = sourceUri.replaceAll("/source/main$", "");
            session = AdtSystemSessionFactory.createSystemSessionFactory()
                .createStatefulSession(destination);

            // 1) LOCK
            IResponse lock = send(session, IRequest.Method.POST,
                lockUri + "?_action=LOCK&accessMode=MODIFY",
                "application/vnd.sap.as+xml;charset=UTF-8;dataname=com.sap.adt.lock.result;q=0.9, "
                    + "application/vnd.sap.as+xml;charset=UTF-8;dataname=com.sap.adt.lock.result2;q=0.8",
                null, null);
            String lockBody = bodyOf(lock);
            if (lock.getStatus() >= 400) {
                return error("LOCK failed " + lock.getStatus() + ": " + trim(lockBody));
            }
            Matcher m = LOCK_HANDLE.matcher(lockBody);
            if (!m.find()) {
                return error("LOCK returned no handle: " + trim(lockBody));
            }
            handle = m.group(1);

            // 2) PUT source
            StringBuilder q = new StringBuilder(sourceUri)
                .append("?lockHandle=").append(URLEncoder.encode(handle, StandardCharsets.UTF_8));
            if (!isEmpty(transport)) {
                q.append("&corrNr=").append(URLEncoder.encode(transport, StandardCharsets.UTF_8));
            }
            IResponse put = send(session, IRequest.Method.PUT, q.toString(), "text/plain",
                "text/plain; charset=utf-8", source.getBytes(StandardCharsets.UTF_8));
            String putBody = bodyOf(put);
            if (put.getStatus() >= 400) {
                return error("PUT failed " + put.getStatus() + ": " + trim(putBody));
            }
            return AdtMcpToolCallResultBuilder.builder()
                .withContent("{\"status\":" + put.getStatus() + ",\"written\":true,\"bytes\":"
                    + source.getBytes(StandardCharsets.UTF_8).length
                    + ",\"note\":\"saved inactive; activate with abap_activate_objects\"}")
                .isError(false)
                .build();
        } catch (Throwable t) {
            return error("arc1_sap_write_source failed: " + t.getClass().getSimpleName()
                + ": " + String.valueOf(t.getMessage()));
        } finally {
            if (session != null) {
                try {
                    if (handle != null && lockUri != null) {
                        send(session, IRequest.Method.POST,
                            lockUri + "?_action=UNLOCK&lockHandle="
                                + URLEncoder.encode(handle, StandardCharsets.UTF_8),
                            null, null, null);
                    }
                } catch (Throwable ignore) {
                    // best effort
                }
                try {
                    session.close();
                } catch (Throwable ignore) {
                    // best effort
                }
            }
        }
    }

    private static IResponse send(IStatefulSystemSession s, IRequest.Method method, String uri,
                                  String accept, String contentType, byte[] body) {
        IHeaders headers = HeadersFactory.newHeaders();
        if (accept != null) {
            headers.setField(HeadersFactory.newField("Accept", accept));
        }
        IMessageBody mb = body == null ? null : new ByteArrayMessageBody(contentType, body);
        IRequest req = AdtRequestFactory.createRequestFactory()
            .createInstance(method, URI.create(uri), headers, mb);
        return s.sendRequest(new NullProgressMonitor(), req);
    }

    private static String bodyOf(IResponse r) throws IOException {
        if (r.getBody() == null) {
            return "";
        }
        try (java.io.InputStream in = r.getBody().getContent()) {
            return in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /** Returns null when allowed, else the reason. */
    private static String checkAllowList(String destination, String transport) throws IOException {
        Path f = Paths.get(System.getProperty("user.home"), ".arc1", "eclipse-write-allow.txt");
        if (!Files.isRegularFile(f)) {
            return "allow-list file not found: " + f;
        }
        Set<String> dests = new HashSet<>();
        Set<String> trs = new HashSet<>();
        boolean local = false;
        List<String> lines = Files.readAllLines(f, StandardCharsets.UTF_8);
        for (String raw : lines) {
            String l = raw.trim();
            if (l.isEmpty() || l.startsWith("#") || !l.contains("=")) {
                continue;
            }
            String k = l.substring(0, l.indexOf('=')).trim().toLowerCase();
            String v = l.substring(l.indexOf('=') + 1).trim();
            if (k.equals("destination")) {
                dests.add(v);
            } else if (k.equals("transport")) {
                trs.add(v.toUpperCase());
            } else if (k.equals("local")) {
                local = v.equalsIgnoreCase("true");
            }
        }
        if (!dests.contains(destination)) {
            return "destination not in allow-list: " + destination;
        }
        if (isEmpty(transport)) {
            return local ? null : "transport required (and not listed with local=true)";
        }
        if (!trs.contains(transport.toUpperCase())) {
            return "transport not in allow-list: " + transport;
        }
        return null;
    }

    private static String trim(String s) {
        return s.length() > 600 ? s.substring(0, 600) + "..." : s;
    }

    private static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    private static IAdtMcpToolCallResult error(String msg) {
        return AdtMcpToolCallResultBuilder.builder()
            .withContent(msg)
            .isError(true)
            .build();
    }
}
