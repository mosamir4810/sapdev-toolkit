package com.arc1.mcp;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.runtime.NullProgressMonitor;

import com.sap.adt.communication.message.AdtRequestFactory;
import com.sap.adt.communication.message.HeadersFactory;
import com.sap.adt.communication.message.IHeaders;
import com.sap.adt.communication.message.IRequest;
import com.sap.adt.communication.message.IResponse;
import com.sap.adt.communication.session.AdtSystemSessionFactory;
import com.sap.adt.communication.session.IStatefulSystemSession;
import com.sap.adt.mcp.core.AdtMcpToolCallResultBuilder;
import com.sap.adt.mcp.core.IAdtMCPTool;
import com.sap.adt.mcp.core.IAdtMcpToolCallResult;

/**
 * Deletes an ABAP object that lives in package $TMP only (local, untransported).
 * Reads the object's package first and refuses anything else. Destination must be
 * listed in ~/.arc1/eclipse-write-allow.txt (destination=...).
 */
public class Arc1SapDeleteObjectTool implements IAdtMCPTool {

    private static final Pattern LOCK_HANDLE = Pattern.compile("<LOCK_HANDLE>([^<]*)</LOCK_HANDLE>");
    private static final Pattern PKG = Pattern.compile("adtcore:packageRef[^>]*adtcore:name=\"([^\"]*)\"");

    @Override
    public String getName() {
        return "arc1_sap_delete_object";
    }

    @Override
    public String getDescription() {
        return "Delete an ABAP object (objectUri e.g. /sap/bc/adt/programs/programs/ZX) via ADT lock+DELETE. "
             + "ONLY objects in package $TMP are deleted; anything else is refused. "
             + "Destination must be in ~/.arc1/eclipse-write-allow.txt.";
    }

    @Override
    public String getInputSchema() {
        return "{\"type\":\"object\",\"properties\":{"
            + "\"destination\":{\"type\":\"string\",\"description\":\"ADT destination ID\"},"
            + "\"objectUri\":{\"type\":\"string\",\"description\":\"Object URI without /source/main\"}"
            + "},\"required\":[\"destination\",\"objectUri\"]}";
    }

    @Override
    public IAdtMcpToolCallResult execute(String jsonInput) {
        IStatefulSystemSession session = null;
        String uri = null;
        String handle = null;
        try {
            String destination = Json.readString(jsonInput, "destination");
            uri = Json.readString(jsonInput, "objectUri");
            if (destination == null || destination.isEmpty() || uri == null || uri.isEmpty()) {
                return error("Missing required field (destination, objectUri)");
            }
            if (!uri.startsWith("/sap/bc/adt/") || uri.contains("?") || uri.contains("/source/")) {
                return error("objectUri must be a plain object path /sap/bc/adt/... (no query, no /source/)");
            }
            if (!destinationAllowed(destination)) {
                return error("Delete refused: destination not in allow-list: " + destination);
            }
            // package check (stateless GET)
            AdtHttp.Response info = AdtHttp.get(destination, uri, "application/xml");
            if (info.status >= 400) {
                return error("Object lookup failed " + info.status + ": " + info.bodyAsString());
            }
            Matcher pm = PKG.matcher(info.bodyAsString());
            if (!pm.find() || !"$TMP".equalsIgnoreCase(pm.group(1))) {
                return error("Delete refused: object is not in $TMP (package "
                    + (pm.find(0) ? pm.group(1) : "unknown") + ")");
            }

            session = AdtSystemSessionFactory.createSystemSessionFactory().createStatefulSession(destination);
            IResponse lock = send(session, IRequest.Method.POST, uri + "?_action=LOCK&accessMode=MODIFY",
                "application/vnd.sap.as+xml;charset=UTF-8;dataname=com.sap.adt.lock.result;q=0.9, "
                    + "application/vnd.sap.as+xml;charset=UTF-8;dataname=com.sap.adt.lock.result2;q=0.8");
            String lockBody = bodyOf(lock);
            if (lock.getStatus() >= 400) {
                return error("LOCK failed " + lock.getStatus() + ": " + lockBody);
            }
            Matcher m = LOCK_HANDLE.matcher(lockBody);
            if (!m.find()) {
                return error("LOCK returned no handle: " + lockBody);
            }
            handle = m.group(1);
            IResponse del = send(session, IRequest.Method.DELETE,
                uri + "?lockHandle=" + URLEncoder.encode(handle, StandardCharsets.UTF_8), null);
            String delBody = bodyOf(del);
            if (del.getStatus() >= 400) {
                return error("DELETE failed " + del.getStatus() + ": " + delBody);
            }
            handle = null; // object gone, nothing to unlock
            return AdtMcpToolCallResultBuilder.builder()
                .withContent("{\"deleted\":true,\"status\":" + del.getStatus() + "}")
                .isError(false)
                .build();
        } catch (Throwable t) {
            return error("arc1_sap_delete_object failed: " + t.getClass().getSimpleName()
                + ": " + String.valueOf(t.getMessage()));
        } finally {
            if (session != null) {
                try {
                    if (handle != null) {
                        send(session, IRequest.Method.POST,
                            uri + "?_action=UNLOCK&lockHandle=" + URLEncoder.encode(handle, StandardCharsets.UTF_8),
                            null);
                    }
                } catch (Throwable ignore) {
                    // best effort
                }
                try {
                    session.close();
                } catch (Throwable ignore) {
                    // best effort
                }
            }
        }
    }

    private static IResponse send(IStatefulSystemSession s, IRequest.Method method, String uri, String accept) {
        IHeaders headers = HeadersFactory.newHeaders();
        if (accept != null) {
            headers.setField(HeadersFactory.newField("Accept", accept));
        }
        IRequest req = AdtRequestFactory.createRequestFactory()
            .createInstance(method, URI.create(uri), headers, null);
        return s.sendRequest(new NullProgressMonitor(), req);
    }

    private static String bodyOf(IResponse r) throws IOException {
        if (r.getBody() == null) {
            return "";
        }
        try (java.io.InputStream in = r.getBody().getContent()) {
            return in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static boolean destinationAllowed(String destination) throws IOException {
        Path f = Paths.get(System.getProperty("user.home"), ".arc1", "eclipse-write-allow.txt");
        if (!Files.isRegularFile(f)) {
            return false;
        }
        for (String raw : Files.readAllLines(f, StandardCharsets.UTF_8)) {
            String l = raw.trim();
            if (l.toLowerCase().startsWith("destination=")
                && l.substring(l.indexOf('=') + 1).trim().equals(destination)) {
                return true;
            }
        }
        return false;
    }

    private static IAdtMcpToolCallResult error(String msg) {
        return AdtMcpToolCallResultBuilder.builder().withContent(msg).isError(true).build();
    }
}
