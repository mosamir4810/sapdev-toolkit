# Build com.arc1.mcp_<version>.jar on Windows (the upstream build.sh targets macOS).
# Needs: JDK 21 or newer (javac + jar on PATH or JAVA_HOME), and the Eclipse/ADT bundles in the p2 pool
# (created when you installed Eclipse with ADT): %USERPROFILE%\.p2\pool\plugins
#
# Usage (from this folder):   powershell -ExecutionPolicy Bypass -File .\build-windows.ps1 [-Pool <plugins folder>] [-Out <folder>]
param(
  [string]$Pool = "$env:USERPROFILE\.p2\pool\plugins",
  [string]$Out = "$PSScriptRoot\out"
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$javac = if ($env:JAVA_HOME) { Join-Path $env:JAVA_HOME 'bin\javac.exe' } else { (Get-Command javac -ErrorAction Stop).Source }
$jar = Join-Path (Split-Path $javac) 'jar.exe'
if (-not (Test-Path $Pool)) { throw "Plugin pool not found: $Pool (pass -Pool, e.g. <eclipse>\plugins)" }

$bundles = 'com.sap.adt.mcp.core','com.sap.adt.ris.search','com.sap.adt.tools.core','com.sap.adt.tools.core.base',
  'com.sap.adt.project','com.sap.adt.destinations','com.sap.adt.destinations.model','com.sap.adt.communication',
  'org.eclipse.core.runtime','org.eclipse.core.resources','org.eclipse.core.jobs','org.eclipse.equinox.common',
  'org.eclipse.osgi','org.eclipse.ui','org.eclipse.ui.workbench','org.eclipse.emf.ecore','org.eclipse.emf.common'

$cp = foreach ($b in $bundles) {
  $hit = Get-ChildItem $Pool -Filter "$b`_*.jar" |
    Where-Object { $_.Name -match ('^' + [regex]::Escape($b) + '_\d') } |
    Sort-Object { [version](($_.Name -replace '^.*?_(\d+(\.\d+){0,3}).*$', '$1')) } | Select-Object -Last 1
  if (-not $hit) { throw "Bundle $b not found in $Pool" }
  Write-Host "  cp += $($hit.Name)"
  $hit.FullName
}

$build = Join-Path $PSScriptRoot 'build'
if (Test-Path $build) { Remove-Item $build -Recurse -Force }
New-Item -ItemType Directory $build | Out-Null
$sources = Get-ChildItem src -Recurse -Filter *.java | ForEach-Object { $_.FullName }
& $javac -d $build --release 21 -cp ($cp -join ';') @sources
if ($LASTEXITCODE -ne 0) { throw 'javac failed' }

New-Item -ItemType Directory "$build\META-INF" | Out-Null
Copy-Item META-INF\MANIFEST.MF "$build\META-INF\MANIFEST.MF"
Copy-Item plugin.xml "$build\plugin.xml"
$version = ((Get-Content META-INF\MANIFEST.MF | Where-Object { $_ -like 'Bundle-Version:*' }) -split ':\s*')[1].Trim()
New-Item -ItemType Directory -Force $Out | Out-Null
$jarFile = Join-Path $Out "com.arc1.mcp_$version.jar"
if (Test-Path $jarFile) { Remove-Item $jarFile }
& $jar cfm $jarFile "$build\META-INF\MANIFEST.MF" -C $build .
if ($LASTEXITCODE -ne 0) { throw 'jar failed' }
Write-Host "Built $jarFile"
Write-Host "Install: copy it to <eclipse>\dropins\, close Eclipse completely, start it once with -clean."
