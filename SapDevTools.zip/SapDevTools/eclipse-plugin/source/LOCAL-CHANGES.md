# Changes against upstream

Upstream: github.com/arc-mcp/arc1-adt-abap-mcp-ext, tag v0.5.1 (commit 000ac53 "chore: automate local release publishing"), MIT licence (see `LICENSE`, copyright the upstream author).

This copy is version 0.6.2 and differs from upstream like this:

1. `src/com/arc1/mcp/Arc1SapWriteSourceTool.java` (new): tool `arc1_sap_write_source`. Locks an existing object, uploads its source and unlocks, in one stateful ADT session. Does not activate. Guarded by `~/.arc1/eclipse-write-allow.txt` (`destination=`, `transport=`, `local=true`), read on every call.
2. `src/com/arc1/mcp/Arc1SapDeleteObjectTool.java` (new): tool `arc1_sap_delete_object`. Deletes an object, restricted to local (`$TMP`) objects and to destinations in the same allow-list file.
3. `src/com/arc1/mcp/Json.java`: fixed a StackOverflowError when reading very large JSON strings (possessive regex).
4. `plugin.xml`: registers the two new tools. `META-INF/MANIFEST.MF`: `Bundle-Version: 0.6.2`.
5. `build-windows.ps1` (new): Windows build script.

Upstream's design notes say mutating tools are out of scope for the upstream project; these two tools are local additions, kept behind the allow-list guard. They are not part of the upstream release.
