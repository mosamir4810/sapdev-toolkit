# Lessons learned (read before changing or extending the tools)

## ADT / transport
- Send `X-CSRF-Token: Fetch` on `/sap/bc/adt/core/discovery` once, reuse cookies; locking and source upload need a **stateful** session (`X-sap-adt-sessiontype: stateful`).
- ADT rejects any source line over **255 characters**.
- SQL preview: POST text/plain to `/sap/bc/adt/datapreview/freestyle?rowNumber=N` with `Accept: application/vnd.sap.adt.datapreview.table.v1+xml`. One SELECT only; spaces around `=`; text literals max 255 chars; very long statements fail; it is read-only.
- The class-run endpoint (`POST /sap/bc/adt/oo/classrun/<CLASS>`, Accept text/plain) takes **no parameters** -> parameters are baked into the class source by rendering a template; a freshly activated class can answer "does not implement if_oo_adt_classrun~main" for a moment, retry after 3 s.
- Classes: POST `/sap/bc/adt/oo/classes` (content type `application/vnd.sap.adt.oo.classes.v2+xml`), LOCK (`?_action=LOCK&accessMode=MODIFY`), PUT `source/main?lockHandle=`, UNLOCK, POST `/sap/bc/adt/activation?method=activate&preauditRequested=true`. Activation errors come back inside a 200 response (`<msg type="E">`); parse them.
- Git Bash on Windows rewrites arguments that start with `/` (e.g. `/sap/bc/...`) into Windows paths; use PowerShell or the Node tool.
- Never loop on a failing logon: SAP locks the user.

## Business Workflow
- Two copies of every definition: `SWD_*` tables (client specific, `EXETYP = 'E'` executable, `VERSION` 0000..000n history) and `SWDS*` tables (`EXETYP = 'S'`, the editor copy with all nodes). Use `E` for what runs.
- Key tables: `SWD_HEADER`, `SWD_NODES`/`SWD_NODES2`, `SWD_LINES`, `SWD_BINDEF`, `SWD_CONDEF`, texts in `SWDSTEXT`; `SWDSSTEPS`, `SWDSMNODES`, `SWDSMLINES`, `SWDSBINDEF`, `SWDSCONT`, `SWDSEXPR`, `SWDSEVNTS`, `SWDSPROPTS`. Runtime: `SWWWIHEAD`, `SWWLOGHIST`, `SWP_HEADER`, `SWPSTEPLOG`, `SWETYPECOU`.
- API: `SWD_WF_DEFINITION_READ` (pass `refresh_buffer = 'X'`, key exetyp `E`, task = workflow id). `SWD_WF_DEFINITION_LOAD_EXPORT/IMPORT` work on a shared buffer, so they return nothing for a definition that is not loaded. Other useful FMs: `SWD_WORKFLOW_STORE`, `SWD_WF_DEFINITION_ACTIVATE`, `SWD_WF_DEFINITION_COPY`, `SWD_WF_DEFINITION_DELETE`, `SWD_TASK_CREATE`. There is no ADT editor for workflows.
- Flexible workflow: `SWDSFLXHEAD`, `SWDSFLXRUSE/RUTX/OUT/REFT/VHLP`, scenario registry `SWF_FLEX_SCREG` (definition class + runtime class + lead object CDS view), `SWF_FLEX_SCACT`, `SWF_FLEX_SC_ORD`, `SWF_FLEX_SCSTAGE`, decision reasons `SWF_FLEX_DECRSN*`.
- Writes via these APIs are not released APIs: test on a throwaway workflow id first.

## SICF / REST
- SICF node names are stored **upper case**; the root `DEFAULT_HOST` has the all-zero GUID (25 zeros); path walk = `ICFSERVICE` by `ICF_NAME` + `ICFPARGUID`.
- Node creation from code: `CL_ICF_TREE->IF_ICF_TREE~INSERT_NODE` (`ICFNODGUID` is an EXPORTING parameter; handler list `ICFHNDLIST` is a table of plain handler names; `application` is `AKHKOMPO`, e.g. `BC`).
- It needs SICF authority. Without it you get message 00/150 "not authorized to use function ...". **Do not bypass** (no suppress-authority parameters); ask Basis or create the node in SICF.
- Handler options: `IF_HTTP_EXTENSION` (simple) or `CL_REST_HTTP_HANDLER` + resource classes (several routes). Use `/ui2/cl_json=>serialize` for JSON. Call write methods with a CSRF token.

## OData V2
- Classic push model: model class inherits `/IWBEP/CL_MGW_PUSH_ABS_MODEL` and redefines **`DEFINE`** (not an interface method). `bind_structure` creates the properties; mark keys with `get_property(...)->set_is_key( )`.
- Data class inherits `/IWBEP/CL_MGW_PUSH_ABS_DATA`: it has an abstract **protected** method `CHECK_SUBSCRIPTION_AUTHORITY` that must be redefined; an empty body was reported as "implementation missing", raising `/iwbep/cx_mgw_not_impl_exc=>method_not_implemented` works.
- Entity-set read uses `io_tech_request_context->get_osql_where_clause_convert( )`, `is_paging`, `has_inlinecount( )`.
- Registration is configuration (`/IWBEP/REG_MODEL`, `/IWBEP/REG_SERVICE`, `/IWFND/MAINT_SERVICE`). On S/4HANA 2020+ the RAP route (CDS + service definition + V2 service binding) is the modern alternative; ADT can create those.

## Eclipse bridge
- SAP's own ADT MCP server (Preferences > ABAP Development > MCP Server, default port 2234, bearer token) reuses Eclipse's project logon, so it also reaches systems whose web dispatcher or router blocks direct `/sap/bc/adt` calls. The ARC-1 plugin (`com.arc1.mcp_<version>.jar` in `dropins/`, started once with `-clean`) adds tools such as `arc1_sap_http_get/post`, `arc1_sap_read_source`, `arc1_sap_search`, `arc1_sap_where_used`.
- If the preference page is missing, add `-DadtMcpServerPrefEnabled=true` as the last line of `eclipse.ini` with Eclipse closed.
- Close Eclipse fully (no `eclipse.exe` left) before swapping a jar; two overlapping instances made the plugin tools fail to register. The Oomph update dialog after `-clean`: Skip.
- After each restart: log on to the ABAP project again, then restart or reconnect the Claude session (MCP tools load at session start).
- Some systems have no DDIC source endpoint via ADT (tables and structures return 404); use `sql` against `DD02L`/`DD03L` instead.
- The token is a credential: keep it in an environment variable, never in chat or in project files.
- The `via: eclipse` transport of this toolkit maps arguments by reading the bridge's tool schema at runtime; it has not been verified against a live Eclipse.

## Working rules
- Read-only by default; every write needs the user's explicit go-ahead, `--confirm`, a named package and (for transportable packages) a transport. Local `$TMP` objects are for tests.
- Never print or store passwords in chat, files in the project, or logs. The user types them with `set-password`.
- Keep AI/tool traces out of SAP: neutral class names (`ZCL_SDT_*`), no "Claude"/"AI" in descriptions or comments.
- Respect read-only systems (e.g. productive or payroll systems): only `sql`, `wf list/show`, `flex`, `sicf info`.
