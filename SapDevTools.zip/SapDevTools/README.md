# sapdev - portable SAP developer toolkit

One Node.js file that works against **any SAP system with ADT enabled** (ABAP Development Tools / Eclipse backend):

- read and inspect **SAP Business Workflow** and **Flexible Workflow** definitions
- generate and deploy **REST services** (SICF handler classes) and create the SICF node
- generate and deploy classic **OData V2** model/data provider classes
- run read-only **SQL** against any table through the ADT data preview
- deploy and run helper **ABAP classes** (class run) without touching SAP GUI

It stores **no credentials and no system names**. You add your own (see "Credentials").

## 1. Prerequisites

| Needed | Why | Check / install |
|---|---|---|
| **Node.js 18 or newer** (22 recommended) | runs `sapdev.js` | `node --version`; Windows `winget install OpenJS.NodeJS.LTS`, macOS `brew install node`, Linux your package manager or nodejs.org |
| Network path to the SAP system | ADT runs over HTTPS (often port 44300 or 443) | VPN if the system is internal |
| SAP user with ADT authority | `S_ADT_RES`, `S_DEVELOP` (display for reading; change for deploying), `S_RFC` not needed | ask Basis if a call returns 401/403 |
| ADT services active in SICF | `/sap/bc/adt` must be active on the system | ask Basis (transaction SICF) |

Nothing else: **no npm install, no Python, no extra packages.** Optional: Eclipse with the ARC-1 plugin if you want the `via: eclipse` transport (experimental).

Run `node sapdev.js prereqs` to check your machine.

## 2. Credentials (never stored in the project)

`systems.json` only says *where* a password is. The password itself lives outside the project.

```bash
# 1. register the system (no password involved)
node sapdev.js add-system dev --url https://sap-dev.example.com:44300 --user MYUSER --client 100 [--insecure]

# 2. enter the password: typed hidden, saved to ~/.sapdev/credentials.env (permissions 600)
node sapdev.js set-password dev

# 3. verify
node sapdev.js dev doctor
```

Alternative for CI/shared machines: keep the password in an environment variable, never in a file:

```bash
node sapdev.js add-system dev --url https://... --user MYUSER --password-env SAP_PASSWORD_DEV
export SAP_PASSWORD_DEV='...'        # PowerShell: $env:SAP_PASSWORD_DEV = '...'
```

Where things go: `~/.sapdev/systems.json` (systems), `~/.sapdev/credentials.env` (passwords). Override with `SAPDEV_CONFIG=/path/systems.json`. `systems.example.json` shows every field. `--insecure` (or `"insecure": true`) disables TLS certificate checks for self-signed internal systems; prefer fixing the certificate chain.
If a password contains special characters, `set-password` handles quoting for you.

Important: SAP locks users after repeated wrong passwords. If `doctor` says 401, fix the password once; do not retry in a loop.

## 3. Quick start

```bash
node sapdev.js dev doctor                      # what does this system support?
node sapdev.js dev sql "SELECT * FROM T000" --rows 5
node sapdev.js dev wf list                     # executable workflow definitions
node sapdev.js dev wf show WS90000001          # header, steps, nodes, bindings
node sapdev.js dev flex list                   # flexible workflow scenarios
node sapdev.js dev rest scaffold --class ZCL_MY_REST --table MARA --deploy
node sapdev.js dev odata scaffold --name ZMY_SRV --table MARA --entity Material --deploy
```

Every command that **writes** to SAP needs `--confirm` (or `--deploy`) and goes into package `$TMP` (local, no transport) unless you set `--package` + `--transport` or the same in `systems.json`.

## 4. Commands

```
add-system <name> --url U --user X [--client 100] [--insecure] [--package P] [--transport T]
set-password <name>
systems                                         list configured systems
<sys> doctor                                    logon + capability check
<sys> sql "<SELECT ...>" [--rows N]             read-only
<sys> classrun <CLASS>                          run an IF_OO_ADT_CLASSRUN class
<sys> deploy <template> --param K=V ...         render a template, upload, activate, run
<sys> delete-class <CLASS> --confirm
<sys> helpers [install --confirm]               generic helper classes (see section 6)
<sys> wf list|show|export                       read workflows
<sys> wf activate|copy ... --confirm            EXPERIMENTAL writes
<sys> flex list|show                            flexible workflow
<sys> sicf info <path>                          e.g. /sap/bc
<sys> sicf create --parent /sap/bc --name ZSVC --handler ZCL_X --descr "..." --confirm
<sys> rest scaffold --class C --table T [--max-rows N] [--deploy]
<sys> odata scaffold --name ZXXX_SRV --table T [--entity E] [--set S] [--deploy]
prereqs | readme | knowledge | prompt | extract [folder]
```

## 5. How it works

- `sql` posts a SELECT to `/sap/bc/adt/datapreview/freestyle` (read-only, one statement).
- Workflow/flex readers are SQL over the workflow tables; `wf export` runs a generated class that calls the standard `SWD_WF_DEFINITION_READ`.
- ABAP classes are created, locked, uploaded, activated and executed over ADT (`/sap/bc/adt/oo/classes`, `/sap/bc/adt/activation`, `/sap/bc/adt/oo/classrun`). The class-run endpoint takes no parameters, so each command **renders a template** with its parameters and re-uploads it.
- Helper classes are named `ZCL_SDT_*` and contain nothing but code; they live in `$TMP` unless you choose another package.

## 6. Helper classes (formerly created in $TMP)

`sapdev <sys> helpers` lists, and `helpers install --confirm` installs, these generic classes from the embedded sources:

- `ZCL_FORM_API_RUN` - runs Adobe Forms / form-interface API calls and reads tables through one class-run entry point
- `ZCL_DYN_READ_RUN` - example: dumps a program's text pool and GUI status (program name is hard-coded: edit it before use)
- `ZCL_REST_PING` - minimal SICF test handler (returns JSON greeting)

The per-command classes (`ZCL_SDT_WF`, `ZCL_SDT_SICF`, ...) are deployed automatically when you use the matching command.

## 7. Eclipse

- Anything this tool deploys is a normal class in the system, so in Eclipse (ADT) you can open it, and run the `IF_OO_ADT_CLASSRUN` ones with F9.
- Transport `"via": "eclipse"` sends the same HTTP calls through the ARC-1 Eclipse plugin's MCP bridge (`http://localhost:2234/mcp`, bearer token from Eclipse preferences, `eclipseProject` = the ABAP project name). **Experimental and not verified against a live Eclipse in this build.** Run `doctor` first.

Setting up the Eclipse side (you click, the tool only talks to it):

1. **Prerequisites:** Eclipse with ABAP Development Tools (ADT), and an ABAP project per system, logged on.
2. **Enable the MCP server:** Window > Preferences > ABAP Development > MCP Server: Enable, port 2234, copy the token. If the page is missing: close Eclipse, add `-DadtMcpServerPrefEnabled=true` as the last line of `eclipse.ini` (keep a `.bak`), restart.
3. **Extra tools (ARC-1 plugin, jar included):** the jar `com.arc1.mcp_0.6.2.jar`, its source, MIT licence, a Windows build script and `INSTALL-ECLIPSE.md` ship in the `eclipse-plugin/` folder (also embedded in `sapdev.js`; `node sapdev.js extract <folder>` unpacks them). Needs ADT 3.60+. Close Eclipse completely, run `node sapdev.js eclipse-plugin install "<eclipse folder>" --confirm` (or copy the jar into `<eclipse>/dropins/` yourself), start once with `-clean` (skip the Oomph update dialog). Upstream project: github.com/arc-mcp/arc1-adt-abap-mcp-ext; this build adds two guarded write tools (see `eclipse-plugin/source/LOCAL-CHANGES.md`).
4. **Check it runs:** Error Log shows "MCP Server started successfully on port 2234"; `curl -i http://localhost:2234/mcp` answers 401 without a token.
5. **Keep the token out of files and chat:** put it in an environment variable, e.g. PowerShell `setx ECLIPSE_MCP_TOKEN "<token>"` and open a new terminal.
6. **Register:** `node sapdev.js add-system dev-eclipse --via eclipse --eclipse-token-env ECLIPSE_MCP_TOKEN --eclipse-project <ABAP project name>` then `node sapdev.js dev-eclipse doctor`.
7. **After every Eclipse restart:** log on to the ABAP project again; restart Claude sessions that use the MCP tools (they only load at session start).

## 8. Limits and honest status

Verified end to end on an S/4HANA 2022 system: `doctor`, `sql`, `wf list/show/export`, `flex list`, `sicf info`, `rest scaffold --deploy` (compiles and activates), `odata scaffold --deploy` (both classes compile and activate), user config and `set-password`.

Not verified: `sicf create` (needs SICF authority; it failed with "not authorized" for the test user), a live call of a generated REST service, OData service registration and a live `$metadata`/data call, `wf copy`, `wf activate`, and the Eclipse transport.

OData registration is configuration, not code: transactions `/IWBEP/REG_MODEL`, `/IWBEP/REG_SERVICE`, then `/IWFND/MAINT_SERVICE` (add service, system alias, ICF node, package/transport).

Run `node sapdev.js knowledge` for the technical lessons learned.
