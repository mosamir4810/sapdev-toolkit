#!/usr/bin/env node
'use strict';
// sapdev - portable SAP developer toolkit (workflow, flexible workflow, SICF/REST, OData scaffolds) for ANY system with ADT.
// Run `node sapdev.js help`.
const fs = require('fs');
const path = require('path');
const { connect, loadSystem, findConfig, userDir, expandHome } = require('./lib/adt');
const A = require('./lib/abapobj');

const argv = process.argv.slice(2);
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) {
    const k = argv[i].slice(2);
    if (i + 1 >= argv.length || argv[i + 1].startsWith('--')) flags[k] = true; else flags[k] = argv[++i];
  } else pos.push(argv[i]);
}
const [system, group, sub, ...rest] = pos;
const q = (s) => String(s).replace(/'/g, "''");

const HELP = `sapdev <system> <group> <command> [args] [--flags]

Systems come from systems.json (see systems.example.json). Transport: --via adt (default) or eclipse (per system).

  sapdev add-system <name> --url https://host:44300 --user U [--client 100] [--insecure] [--package P] [--transport T]
                                                   add/update a system (stores NO password)
  sapdev set-password <name>                       type the password (hidden); saved to ~/.sapdev/credentials.env, outside the project
                                                   (alternative: --password-env VAR on add-system, then export VAR)
  sapdev systems                                   list configured systems (no passwords shown)
  sapdev <sys> doctor                              check logon, ADT discovery, SQL preview, class run
  sapdev <sys> sql "<SELECT ...>" [--rows N]       read-only SQL through ADT data preview
  sapdev <sys> deploy <template> --param K=V ...   render an ABAP template, upload, activate, run it
  sapdev <sys> classrun <CLASS>                    run an existing IF_OO_ADT_CLASSRUN class
  sapdev <sys> helpers [install --confirm]         list / install the generic helper classes (form API runner, dynamic reader, REST ping)
  sapdev prereqs | readme | knowledge | prompt     built-in docs (prerequisites, manual, lessons learned, bootstrap prompt for a new Claude)
  sapdev extract [folder]                          unpack everything embedded (docs, ABAP templates, helper classes, Eclipse plugin jar + source)
  sapdev eclipse-plugin install "<eclipse dir>" --confirm   copy the embedded ARC-1 plugin jar into <eclipse>/dropins (see eclipse-plugin/INSTALL-ECLIPSE.md)
  sapdev <sys> delete-class <CLASS> --confirm      delete a helper class

  sapdev <sys> wf list [pattern] [--rows N]        executable workflow definitions (SWD_HEADER, exetyp E)
  sapdev <sys> wf show <WSnnnnnnnn> [--version 0000] [--exetyp E|S]   header/steps/nodes/bindings via SQL
  sapdev <sys> wf export <WSnnnnnnnn> [--version 0000] [--exetyp E]   same via the standard SWD read API (needs helper class)
  sapdev <sys> wf activate <WS..> --confirm        EXPERIMENTAL: standard activation (writes)
  sapdev <sys> wf copy <WS..> <WSnew> --confirm    EXPERIMENTAL: standard copy to a new id (writes)
  sapdev <sys> flex list [pattern]                 flexible workflow scenarios (SWF_FLEX_SCREG)
  sapdev <sys> flex show <WS..>                    flexible definition: header, reuse units, outcomes, stages

  sapdev <sys> sicf info <path>                    SICF node lookup, e.g. /sap/bc
  sapdev <sys> sicf create --parent /sap/bc --name ZMYSVC --handler ZCL_X --descr "Text" [--appl BC] --confirm
  sapdev <sys> rest scaffold --class ZCL_MY_REST --table MARA [--max-rows 100] [--deploy]
  sapdev <sys> odata scaffold --name ZMY_SRV --table MARA [--deploy]   classic MPC/DPC classes (read-only entity set)

Packages: default from systems.json ("package", $TMP if absent). Non-local packages need --transport or "transport".
`;

function parseParams() {
  const out = {};
  for (const p of [].concat(flags.param || [])) { const i = p.indexOf('='); out[p.slice(0, i)] = p.slice(i + 1); }
  return out;
}
// allow repeated --param by re-scanning argv
const multi = {};
for (let i = 0; i < argv.length; i++) if (argv[i] === '--param' && argv[i + 1]) { const s = argv[i + 1]; const k = s.indexOf('='); multi[s.slice(0, k)] = s.slice(k + 1); }

// ---- configuration (no secrets in systems.json: it only names WHERE the password is)
function userConfigFile() { return process.env.SAPDEV_CONFIG || path.join(userDir(), 'systems.json'); }
function readUserConfig() {
  const f = userConfigFile();
  return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : { defaults: { language: 'EN', package: '$TMP' }, systems: {} };
}
function writeUserConfig(cfg) {
  const f = userConfigFile();
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, JSON.stringify(cfg, null, 2) + '\n');
  return f;
}
function addSystem(name) {
  if (!name) throw new Error('usage: add-system <name> --url https://host:44300 --user <user> [--client 100] [--insecure] [--package Z..] [--transport ...]\n' +
    '       [--password-env VAR | --password-file FILE --password-key KEY]   (or run set-password afterwards)\n' +
    '       [--via eclipse --eclipse-url http://localhost:2234/mcp --eclipse-token-env VAR --eclipse-project NAME]');
  const cfg = readUserConfig();
  const s = {};
  if (flags.via === 'eclipse') {
    Object.assign(s, { via: 'eclipse', url: 'n/a', user: 'n/a', eclipseUrl: flags['eclipse-url'] || 'http://localhost:2234/mcp',
      eclipseTokenEnv: flags['eclipse-token-env'] || 'ECLIPSE_MCP_TOKEN', eclipseProject: flags['eclipse-project'] || '' });
  } else {
    if (!flags.url || !flags.user) throw new Error('--url and --user are required');
    Object.assign(s, { url: String(flags.url).replace(/\/$/, ''), client: String(flags.client || '100'), user: flags.user });
    if (flags.insecure) s.insecure = true;
    if (flags['password-env']) s.passwordEnv = flags['password-env'];
    if (flags['password-file']) { s.passwordFile = flags['password-file']; s.passwordKey = flags['password-key'] || 'SAP_PASSWORD_' + name.toUpperCase(); }
  }
  if (flags.package) s.package = flags.package;
  if (flags.transport) s.transport = flags.transport;
  cfg.systems[name] = s;
  const f = writeUserConfig(cfg);
  console.log('saved system "' + name + '" in ' + f);
  if (!s.passwordEnv && !s.passwordFile && s.via !== 'eclipse') console.log('Next: node sapdev.js set-password ' + name + '   (or set an environment variable and re-add with --password-env)');
}
function readHidden(prompt) {
  return new Promise((resolve) => {
    process.stdout.write(prompt);
    const stdin = process.stdin; let s = '';
    if (!stdin.isTTY) { stdin.setEncoding('utf8'); stdin.on('data', (d) => { s += d; }); stdin.on('end', () => resolve(s.replace(/\r?\n$/, ''))); return; }
    stdin.setRawMode(true); stdin.resume(); stdin.setEncoding('utf8');
    const onData = (ch) => {
      for (const c of ch) {
        if (c === '\r' || c === '\n') { stdin.setRawMode(false); stdin.pause(); stdin.removeListener('data', onData); process.stdout.write('\n'); return resolve(s); }
        if (c === '\u0003') process.exit(130);
        if (c === '\u007f' || c === '\b') s = s.slice(0, -1); else s += c;
      }
    };
    stdin.on('data', onData);
  });
}
async function setPassword(name) {
  if (!name) throw new Error('usage: set-password <system>');
  const cfg = readUserConfig();
  const s = cfg.systems[name];
  if (!s) throw new Error('Unknown system "' + name + '". Add it first: add-system ' + name + ' --url ... --user ...');
  const file = path.join(userDir(), 'credentials.env');
  const key = s.passwordKey && s.passwordFile && expandHome(s.passwordFile) === file ? s.passwordKey : 'SAP_PASSWORD_' + name.toUpperCase().replace(/[^A-Z0-9]/g, '_');
  const pw = await readHidden('Password for ' + name + ' (' + s.user + '): ');
  if (!pw) throw new Error('empty password, nothing saved');
  fs.mkdirSync(userDir(), { recursive: true });
  const lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split(/\r?\n/).filter((l) => l && !l.startsWith(key + '=')) : [];
  lines.push(key + "='" + pw.replace(/'/g, "'\\''") + "'");
  fs.writeFileSync(file, lines.join('\n') + '\n', { mode: 0o600 });
  s.passwordFile = '~/.sapdev/credentials.env'; s.passwordKey = key; delete s.passwordEnv;
  writeUserConfig(cfg);
  console.log('saved password for "' + name + '" in ' + file + ' (never printed, not part of the project). Test: node sapdev.js ' + name + ' doctor');
}

function requireConfirm(what) {
  if (!flags.confirm) { console.error('This changes something (' + what + '). Re-run with --confirm after you checked the target (system, package, object or folder).'); process.exit(3); }
}
function opts() { return { package: flags.package, transport: flags.transport }; }

async function main() {
  if (!pos.length || pos[0] === 'help' || flags.help) { console.log(HELP); return; }
  if (['readme', 'knowledge', 'prompt'].includes(pos[0])) {
    console.log(A.readAsset({ readme: 'README.md', knowledge: 'KNOWLEDGE.md', prompt: 'PROMPT.md' }[pos[0]])); return;
  }
  if (pos[0] === 'prereqs') {
    console.log('Prerequisites');
    console.log('  Node.js 18 or newer (22 recommended)   node --version');
    console.log('  Nothing else: no npm install, no Python, no extra packages. This is one file.');
    console.log('  Network path to the SAP system (VPN if needed) and an SAP user with ADT authorisation (S_ADT_RES, S_DEVELOP).');
    console.log('  Your node version here: ' + process.version + (parseInt(process.version.slice(1), 10) >= 18 ? '  (ok)' : '  (TOO OLD, install Node 18+)'));
    console.log('\nInstall Node.js: Windows `winget install OpenJS.NodeJS.LTS`, macOS `brew install node`, Linux use your package manager or https://nodejs.org');
    return;
  }
  if (pos[0] === 'extract') {   // unpack embedded docs, templates and helper classes to a folder
    const dir = path.resolve(pos[1] || 'sapdev-files');
    const text = Object.keys(global.__SAPDEV_FILES || {});
    const bin = Object.keys(global.__SAPDEV_BIN || {});
    if (!text.length) { console.log('extract only works in the single-file build (dist/sapdev.js); this is the source tree.'); return; }
    for (const n of text) { const f = path.join(dir, n); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, A.readAsset(n)); }
    for (const n of bin) { const f = path.join(dir, n); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, A.readBinary(n)); }
    console.log('extracted ' + (text.length + bin.length) + ' files to ' + dir + ' (docs, ABAP templates, helper classes, Eclipse plugin jar + source)'); return;
  }
  if (pos[0] === 'eclipse-plugin') {   // sapdev eclipse-plugin install "<eclipse folder>" --confirm
    const jarRel = Object.keys(global.__SAPDEV_BIN || {}).find((k) => k.endsWith('.jar')) || 'eclipse-plugin/com.arc1.mcp_0.6.2.jar';
    if (pos[1] === 'install') {
      const eclipse = pos[2];
      if (!eclipse) throw new Error('usage: eclipse-plugin install "<eclipse install folder>" --confirm');
      const dropins = path.join(path.resolve(eclipse), 'dropins');
      if (!fs.existsSync(dropins)) throw new Error('No dropins folder in ' + path.resolve(eclipse) + ' (pass the folder that contains eclipse.exe / eclipse.ini)');
      requireConfirm('copy ' + path.basename(jarRel) + ' into ' + dropins + '. Close Eclipse completely first, then start it once with -clean');
      const target = path.join(dropins, path.basename(jarRel));
      fs.writeFileSync(target, A.readBinary(jarRel));
      console.log('copied to ' + target + '\nNext: close Eclipse completely, start it once with -clean, then follow eclipse-plugin/INSTALL-ECLIPSE.md steps 4-7 (run: node sapdev.js extract).');
      return;
    }
    console.log('usage: eclipse-plugin install "<eclipse install folder>" --confirm\nThe jar, source, license and install guide are inside this file: run `node sapdev.js extract <folder>` to unpack them.');
    return;
  }
  if (pos[0] === 'add-system') return addSystem(pos[1]);
  if (pos[0] === 'set-password') return setPassword(pos[1]);
  if (pos[0] === 'systems') {
    const cfgFile = findConfig();
    if (!cfgFile) { console.log('No systems configured yet. Run: node sapdev.js add-system <name> --url https://host:44300 --user <user> [--client 100]'); return; }
    const cfg = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
    console.log('config: ' + cfgFile);
    for (const [n, s] of Object.entries(cfg.systems)) console.log(n.padEnd(14) + s.url + '  client ' + (s.client || '100') + '  user ' + s.user + '  via ' + (s.via || 'adt') + '  pkg ' + (s.package || '$TMP'));
    return;
  }
  const c = connect(system);
  const cmd = group;
  // ---- generic
  if (cmd === 'doctor') {
    const s = loadSystem(system);
    console.log('system ' + s.name + '  ' + s.url + '  client ' + s.client + '  user ' + s.user + '  via ' + s.via);
    const r = await c.request('GET', '/sap/bc/adt/core/discovery', { accept: 'application/atomsvc+xml' });
    console.log('ADT discovery: HTTP ' + r.status);
    const d = await c.request('GET', '/sap/bc/adt/discovery', { accept: 'application/atomsvc+xml' });
    const has = (p) => d.text.includes(p);
    console.log('SQL preview endpoint:   ' + (has('/sap/bc/adt/datapreview/freestyle') ? 'yes' : 'NO'));
    console.log('Class run endpoint:     ' + (has('/sap/bc/adt/oo/classrun') ? 'yes' : 'NO'));
    console.log('Class create endpoint:  ' + (has('/sap/bc/adt/oo/classes') ? 'yes' : 'NO'));
    try {
      const v = await A.sql(c, "SELECT COMPONENT, RELEASE FROM CVERS WHERE COMPONENT IN ( 'SAP_BASIS', 'S4CORE', 'SAP_GWFND' )", 10);
      console.log('SQL test ok: ' + v.rows.map((x) => x.COMPONENT.trim() + ' ' + x.RELEASE.trim()).join(', '));
    } catch (e) { console.log('SQL test failed: ' + e.message); }
    for (const [n, q2] of [['workflow tables', 'SELECT COUNT(*) AS N FROM SWD_HEADER'], ['flexible workflow tables', 'SELECT COUNT(*) AS N FROM SWDSFLXHEAD'], ['SICF tree', 'SELECT COUNT(*) AS N FROM ICFSERVICE']]) {
      try { const v = await A.sql(c, q2, 1); console.log(n.padEnd(26) + 'readable (' + v.rows[0].N.trim() + ' rows)'); } catch (e) { console.log(n.padEnd(26) + 'not readable'); }
    }
    return;
  }
  if (cmd === 'sql') { console.log(A.table(await A.sql(c, sub, Number(flags.rows) || 100))); return; }
  if (cmd === 'helpers') {   // the helper classes that used to live in $TMP: list or (re)install them on this system
    const files = A.listAssets('abap/extra/');
    if (sub !== 'install') { files.forEach((f) => console.log(f.replace('abap/extra/', '').replace('.abap', '').toUpperCase())); console.log('\nInstall into the system package: sapdev <sys> helpers install --confirm [--package P --transport T]'); return; }
    requireConfirm('install helper classes ' + files.map((f) => f.replace('abap/extra/', '')).join(', '));
    for (const f of files) {
      const src = A.readAsset(f); const name = f.replace('abap/extra/', '').replace('.abap', '').toUpperCase();
      const r = await A.deployClass(c, name, src, Object.assign({ description: 'Dev helper ' + name }, opts()));
      console.log((r.created ? 'created   ' : 'updated   ') + name);
    }
    return;
  }
  if (cmd === 'classrun') { console.log(await A.classRun(c, sub)); return; }
  if (cmd === 'delete-class') { requireConfirm('delete class ' + sub); await A.deleteClass(c, sub, flags.transport); console.log('deleted ' + sub); return; }
  if (cmd === 'deploy') {
    const out = await A.runTemplate(c, sub.endsWith('.abap') ? sub : sub + '.abap', multi, opts());
    console.log(out); return;
  }
  // ---- workflow
  if (cmd === 'wf') {
    if (sub === 'list') {
      const pat = q((rest[0] || '').toUpperCase());
      const r = await A.sql(c, "SELECT WFD_ID, VERSION, ACTIV, CREATED_BY, CHANGED_BY, CHANGED_ON, TASK FROM SWD_HEADER WHERE EXETYP = 'E'" +
        (pat ? " AND WFD_ID LIKE '%" + pat + "%'" : '') + ' ORDER BY CHANGED_ON DESCENDING', Number(flags.rows) || 50);
      console.log(A.table(r)); return;
    }
    if (sub === 'show') {
      const id = q(rest[0].toUpperCase()); const ver = q(flags.version || '0000'); const exe = q(flags.exetyp || 'E');
      const tabs = exe === 'E'
        ? ['SWD_HEADER', 'SWD_STEPS', 'SWD_NODES', 'SWD_NODES2', 'SWD_LINES', 'SWD_BINDEF', 'SWD_CONDEF']
        : ['SWDSHEADER', 'SWDSTEXT', 'SWDSSTEPS', 'SWDSMNODES', 'SWDSMLINES', 'SWDSBINDEF', 'SWDSCONT', 'SWDSCONDEF', 'SWDSEXPR', 'SWDSEVNTS', 'SWDSFUNCS', 'SWDSPROPTS'];
      for (const t of tabs) {
        try {
          const r = await A.sql(c, 'SELECT * FROM ' + t + " WHERE WFD_ID = '" + id + "' AND VERSION = '" + ver + "'" + (exe === 'E' ? " AND EXETYP = 'E'" : ''), 500);
          if (!r.rows.length) continue;
          const keep = r.cols.filter((k) => r.rows.some((x) => !/^[0 ]*$/.test(String(x[k]).trim()) && String(x[k]).trim() !== ''));
          console.log('\n=== ' + t + ' (' + r.rows.length + ')'); console.log(A.table({ cols: keep, rows: r.rows }));
        } catch (e) { console.log('\n=== ' + t + ': ' + e.message.slice(0, 100)); }
      }
      return;
    }
    if (sub === 'export' || sub === 'activate' || sub === 'copy') {
      if (sub !== 'export') requireConfirm('workflow ' + sub);
      const p = { ACTION: sub, WFD_ID: rest[0].toUpperCase(), VERSION: flags.version || '0000', EXETYP: flags.exetyp || 'E', TARGET_ID: (rest[1] || '').toUpperCase() };
      console.log(await A.runTemplate(c, 'sdt_wf.abap', p, opts())); return;
    }
  }
  // ---- flexible workflow
  if (cmd === 'flex') {
    if (sub === 'list') {
      const pat = q((rest[0] || '').toUpperCase());
      const r = await A.sql(c, 'SELECT WFD_ID, CLASS_NAME, RUNTIME_CLASS, LEAD_OBJ_VIEW FROM SWF_FLEX_SCREG' + (pat ? " WHERE WFD_ID LIKE '%" + pat + "%' OR CLASS_NAME LIKE '%" + pat + "%' OR RUNTIME_CLASS LIKE '%" + pat + "%'" : ''), Number(flags.rows) || 50);
      console.log(A.table(r)); return;
    }
    if (sub === 'show') {
      const id = q(rest[0].toUpperCase());
      for (const t of ['SWF_FLEX_SCREG', 'SWF_FLEX_SCACT', 'SWDSFLXHEAD', 'SWDSFLXRUSE', 'SWDSFLXRUTX', 'SWDSFLXOUT', 'SWDSFLXREFT', 'SWF_FLEX_SC_ORD']) {
        try {
          const col = t === 'SWF_FLEX_SC_ORD' ? 'SCENARIO_ID' : 'WFD_ID';
          const r = await A.sql(c, 'SELECT * FROM ' + t + ' WHERE ' + col + " = '" + id + "'", 200);
          if (!r.rows.length) continue;
          const keep = r.cols.filter((k) => r.rows.some((x) => String(x[k]).trim() !== ''));
          console.log('\n=== ' + t + ' (' + r.rows.length + ')'); console.log(A.table({ cols: keep, rows: r.rows }));
        } catch (e) { console.log('\n=== ' + t + ': ' + e.message.slice(0, 100)); }
      }
      return;
    }
  }
  // ---- SICF / REST
  if (cmd === 'sicf') {
    if (sub === 'info') { console.log(await A.runTemplate(c, 'sdt_sicf.abap', { ACTION: 'info', PARENT: rest[0], NAME: '', HANDLER: '', DESCR: '', APPL: 'BC' }, opts())); return; }
    if (sub === 'create') {
      requireConfirm('create SICF node ' + flags.name + ' under ' + flags.parent);
      for (const k of ['parent', 'name', 'handler']) if (!flags[k]) throw new Error('--' + k + ' is required');
      console.log(await A.runTemplate(c, 'sdt_sicf.abap', { ACTION: 'create', PARENT: flags.parent, NAME: String(flags.name).toUpperCase(), HANDLER: String(flags.handler).toUpperCase(), DESCR: flags.descr || flags.name, APPL: flags.appl || 'BC' }, opts()));
      return;
    }
  }
  if (cmd === 'rest' && sub === 'scaffold') {
    for (const k of ['class', 'table']) if (!flags[k]) throw new Error('--' + k + ' is required');
    const { name, source } = A.render('rest_table.abap', { CLASS_NAME: String(flags.class).toUpperCase(), TABLE: String(flags.table).toUpperCase(), MAX_ROWS: flags['max-rows'] || 100 });
    const out = path.join(process.cwd(), name.toLowerCase() + '.abap');
    fs.writeFileSync(out, source);
    console.log('generated ' + out);
    if (flags.deploy) { await A.deployClass(c, name, source, Object.assign({ description: 'REST service for ' + flags.table }, opts())); console.log('deployed + activated ' + name + '. Next: create the SICF node with handler ' + name + ' (sapdev ' + system + ' sicf create ...).'); }
    return;
  }
  if (cmd === 'odata' && sub === 'scaffold') {
    for (const k of ['name', 'table']) if (!flags[k]) throw new Error('--' + k + ' is required');
    const n = String(flags.name).toUpperCase().replace(/^Z/, '');
    const params = { MPC: 'ZCL_' + n + '_MPC', DPC: 'ZCL_' + n + '_DPC', TABLE: String(flags.table).toUpperCase(), ENTITY: flags.entity || String(flags.table).toUpperCase(), SET: flags.set || (flags.entity || String(flags.table)).toUpperCase() + 'Set' };
    for (const f of ['odata_mpc.abap', 'odata_dpc.abap']) {
      const { name, source } = A.render(f, params);
      fs.writeFileSync(path.join(process.cwd(), name.toLowerCase() + '.abap'), source);
      console.log('generated ' + name.toLowerCase() + '.abap');
      if (flags.deploy) { await A.deployClass(c, name, source, Object.assign({ description: 'OData ' + (f.includes('mpc') ? 'model' : 'data') + ' provider ' + flags.name }, opts())); console.log('deployed + activated ' + name); }
    }
    console.log('\nRegistration is a configuration step (not code): transactions /IWBEP/REG_MODEL, /IWBEP/REG_SERVICE, then /IWFND/MAINT_SERVICE. See README.');
    return;
  }
  console.error('Unknown command. Run: node sapdev.js help'); process.exit(2);
}

main().catch((e) => { console.error('ERROR: ' + e.message); process.exit(1); });
