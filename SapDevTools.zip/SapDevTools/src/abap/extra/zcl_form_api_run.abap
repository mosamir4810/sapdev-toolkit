CLASS zcl_form_api_run DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
  PRIVATE SECTION.
    METHODS get_par
      IMPORTING io_par       TYPE REF TO if_fp_parameters
                iv_kind      TYPE string
      RETURNING VALUE(rt_par) TYPE tfpiopar.
    METHODS set_par
      IMPORTING io_par  TYPE REF TO if_fp_parameters
                iv_kind TYPE string
                it_par  TYPE tfpiopar.
    METHODS to_coding
      IMPORTING it_lines TYPE string_table
      RETURNING VALUE(rt_coding) TYPE tfpcoding.
ENDCLASS.

CLASS zcl_form_api_run IMPLEMENTATION.

  METHOD get_par.
    CASE iv_kind.
      WHEN 'import'.    rt_par = io_par->get_import_parameters( ).
      WHEN 'export'.    rt_par = io_par->get_export_parameters( ).
      WHEN 'table'.     rt_par = io_par->get_table_parameters( ).
      WHEN 'exception'. rt_par = io_par->get_exceptions( ).
    ENDCASE.
  ENDMETHOD.

  METHOD set_par.
    CASE iv_kind.
      WHEN 'import'.    io_par->set_import_parameters( it_par ).
      WHEN 'export'.    io_par->set_export_parameters( it_par ).
      WHEN 'table'.     io_par->set_table_parameters( it_par ).
      WHEN 'exception'. io_par->set_exceptions( it_par ).
    ENDCASE.
  ENDMETHOD.

  METHOD to_coding.
    LOOP AT it_lines INTO DATA(lv_line).
      APPEND lv_line TO rt_coding.
    ENDLOOP.
  ENDMETHOD.

  METHOD if_oo_adt_classrun~main.
    TYPES: BEGIN OF ty_sel,
             selname TYPE string,
             kind    TYPE string,
             sign    TYPE string,
             option  TYPE string,
             low     TYPE string,
             high    TYPE string,
           END OF ty_sel,
           BEGIN OF ty_prm,
             name  TYPE string,
             value TYPE string,
           END OF ty_prm,
           BEGIN OF ty_op,
             op       TYPE string,
             kind     TYPE string,
             name     TYPE string,
             typing   TYPE string,
             typename TYPE string,
             optional TYPE string,
             byvalue  TYPE string,
             default  TYPE string,
             standard TYPE string,
             constant TYPE string,
             lines    TYPE string_table,
           END OF ty_op,
           BEGIN OF ty_req,
             action    TYPE string,
             name      TYPE string,
             transport TYPE string,
             source    TYPE string,
             devclass  TYPE string,
             description TYPE string,
             interface TYPE string,
             layout    TYPE string,
             with_layout TYPE string,
             max_rows  TYPE i,
             where_clause TYPE string,
             columns   TYPE string,
             client_specified TYPE string,
             sel       TYPE STANDARD TABLE OF ty_sel WITH EMPTY KEY,
             params    TYPE STANDARD TABLE OF ty_prm WITH EMPTY KEY,
             ops       TYPE STANDARD TABLE OF ty_op WITH EMPTY KEY,
           END OF ty_req,
           BEGIN OF ty_res,
             ok                TYPE string,
             action            TYPE string,
             name              TYPE string,
             description       TYPE string,
             interface         TYPE string,
             layout_type       TYPE string,
             form_tech         TYPE string,
             layout            TYPE string,
             list              TYPE string_table,
             data              TYPE string,
             total_rows        TYPE i,
             pdf               TYPE string,
             fm                TYPE string,
             state             TYPE string,
             devclass          TYPE string,
             ordernum          TYPE string,
             import_parameters TYPE tfpiopar,
             export_parameters TYPE tfpiopar,
             table_parameters  TYPE tfpiopar,
             exceptions        TYPE tfpiopar,
             types             TYPE tfpcoding,
             global_data       TYPE tfpgdata,
             fieldsymbols      TYPE tfpgdata,
             init_coding       TYPE tfpcoding,
             forms_coding      TYPE tfpcoding,
             checklist         TYPE tfpchecklist,
             messages          TYPE string_table,
           END OF ty_res.

    DATA ls_req TYPE ty_req.
    DATA ls_res TYPE ty_res.
    DATA lv_b64 TYPE string.
    DATA lv_xml TYPE xstring.
    DATA lv_json TYPE string.
    DATA lo_wb TYPE REF TO if_fp_wb_interface.

    lv_b64 = lv_b64 && 'eyJhY3Rpb24iOiAicXVlcnkiLCAibmFtZSI6ICJaSFJTSUdOQVRVUkVTIiwgIndoZXJlX2NsYXVzZSI6ICJNQU5EVCA9ICcyMDAnIiwgIm1heF9yb3dzIjogMjAwMCwgImNvbHVtbnMiOiAiKiIsICJjbGllbnRfc3BlY2lmaWVkIjogIlgi'.
    lv_b64 = lv_b64 && 'fQ=='.

    CALL FUNCTION 'SCMS_BASE64_DECODE_STR'
      EXPORTING input = lv_b64
      IMPORTING output = lv_xml
      EXCEPTIONS failed = 1 OTHERS = 2.
    cl_abap_conv_in_ce=>create( encoding = 'UTF-8' )->convert(
      EXPORTING input = lv_xml IMPORTING data = lv_json ).
    /ui2/cl_json=>deserialize( EXPORTING json = lv_json
                                         pretty_name = /ui2/cl_json=>pretty_mode-low_case
                               CHANGING data = ls_req ).

    ls_res-action = ls_req-action.
    ls_res-name = to_upper( ls_req-name ).
    DATA(lv_name) = CONV fpname( ls_res-name ).
    DATA(lv_tr) = CONV trkorr( to_upper( ls_req-transport ) ).

    TRY.
        CASE ls_req-action.
          WHEN 'read' OR 'write'.
            IF ls_req-action = 'write'.
              lo_wb = cl_fp_wb_interface=>load( i_name = lv_name
                                                i_mode = if_fp_wb_object=>c_mode_write
                                                i_ordernum = lv_tr ).
            ELSE.
              lo_wb = cl_fp_wb_interface=>load( i_name = lv_name
                                                i_mode = if_fp_wb_object=>c_mode_read ).
            ENDIF.
            DATA(lo_if) = CAST if_fp_interface( lo_wb->get_object( ) ).
            DATA(lo_data) = lo_if->get_interface_data( ).
            DATA(lo_par) = lo_data->get_parameters( ).
            DATA(lo_glob) = lo_data->get_global_definitions( ).
            DATA(lo_code) = lo_data->get_coding( ).

            LOOP AT ls_req-ops INTO DATA(ls_op).
              CASE ls_op-op.
                WHEN 'param_add' OR 'param_set' OR 'param_remove'.
                  DATA(lt_par) = get_par( io_par = lo_par iv_kind = ls_op-kind ).
                  DATA(lv_pname) = CONV fpvarname( to_upper( ls_op-name ) ).
                  IF ls_op-op = 'param_add'.
                    IF line_exists( lt_par[ name = lv_pname ] ).
                      APPEND |parameter { lv_pname } already exists in { ls_op-kind }| TO ls_res-messages.
                      CONTINUE.
                    ENDIF.
                    APPEND VALUE sfpiopar( name = lv_pname typing = ls_op-typing typename = ls_op-typename
                                           optional = ls_op-optional byvalue = ls_op-byvalue
                                           defaultval = ls_op-default standard = ls_op-standard
                                           constant = ls_op-constant ) TO lt_par.
                  ELSEIF ls_op-op = 'param_remove'.
                    DELETE lt_par WHERE name = lv_pname.
                  ELSE.
                    ASSIGN lt_par[ name = lv_pname ] TO FIELD-SYMBOL(<ls_par>).
                    IF sy-subrc <> 0.
                      APPEND |parameter { lv_pname } not found in { ls_op-kind }| TO ls_res-messages.
                      CONTINUE.
                    ENDIF.
                    IF ls_op-typing IS NOT INITIAL.   <ls_par>-typing = ls_op-typing.     ENDIF.
                    IF ls_op-typename IS NOT INITIAL. <ls_par>-typename = ls_op-typename. ENDIF.
                    IF ls_op-optional IS NOT INITIAL. <ls_par>-optional = ls_op-optional. ENDIF.
                    IF ls_op-byvalue IS NOT INITIAL.  <ls_par>-byvalue = ls_op-byvalue.   ENDIF.
                    IF ls_op-default IS NOT INITIAL.  <ls_par>-defaultval = ls_op-default. ENDIF.
                  ENDIF.
                  set_par( io_par = lo_par iv_kind = ls_op-kind it_par = lt_par ).
                  CLEAR lt_par.
                WHEN 'global_add' OR 'global_remove'.
                  DATA(lt_gd) = lo_glob->get_global_data( ).
                  DATA(lv_gname) = CONV fpvarname( to_upper( ls_op-name ) ).
                  IF ls_op-op = 'global_add'.
                    IF line_exists( lt_gd[ name = lv_gname ] ).
                      APPEND |global { lv_gname } already exists| TO ls_res-messages.
                      CONTINUE.
                    ENDIF.
                    APPEND VALUE sfpgdata( name = lv_gname typing = ls_op-typing typename = ls_op-typename
                                           defaultval = ls_op-default constant = ls_op-constant ) TO lt_gd.
                  ELSE.
                    DELETE lt_gd WHERE name = lv_gname.
                  ENDIF.
                  lo_glob->set_global_data( lt_gd ).
                WHEN 'types_set'.
                  lo_glob->set_types( to_coding( ls_op-lines ) ).
                WHEN 'init_coding_set'.
                  lo_code->set_init_coding( to_coding( ls_op-lines ) ).
                WHEN 'forms_coding_set'.
                  lo_code->set_forms_coding( to_coding( ls_op-lines ) ).
                WHEN OTHERS.
                  APPEND |unknown op { ls_op-op }| TO ls_res-messages.
              ENDCASE.
            ENDLOOP.

            IF ls_req-action = 'write'.
              ls_res-checklist = lo_wb->check( ).
              lo_wb->save( ).
              lo_wb->free( ).
              APPEND 'saved (inactive version); run activate to activate' TO ls_res-messages.
              lo_wb = cl_fp_wb_interface=>load( i_name = lv_name i_mode = if_fp_wb_object=>c_mode_read ).
              lo_if = CAST if_fp_interface( lo_wb->get_object( ) ).
              lo_data = lo_if->get_interface_data( ).
              lo_par = lo_data->get_parameters( ).
              lo_glob = lo_data->get_global_definitions( ).
              lo_code = lo_data->get_coding( ).
            ENDIF.

            ls_res-description = lo_if->if_fp_object~get_description( ).
            ls_res-state = lo_wb->get_state( ).
            ls_res-devclass = lo_wb->get_devclass( ).
            ls_res-ordernum = lo_wb->get_ordernum( ).
            ls_res-import_parameters = lo_par->get_import_parameters( ).
            ls_res-export_parameters = lo_par->get_export_parameters( ).
            ls_res-table_parameters = lo_par->get_table_parameters( ).
            ls_res-exceptions = lo_par->get_exceptions( ).
            ls_res-types = lo_glob->get_types( ).
            ls_res-global_data = lo_glob->get_global_data( ).
            ls_res-fieldsymbols = lo_glob->get_fieldsymbols( ).
            ls_res-init_coding = lo_code->get_init_coding( ).
            ls_res-forms_coding = lo_code->get_forms_coding( ).
            IF ls_req-action = 'read'.
              ls_res-checklist = lo_wb->check( ).
              lo_wb->free( ).
            ENDIF.

          WHEN 'check'.
            lo_wb = cl_fp_wb_interface=>load( i_name = lv_name i_mode = if_fp_wb_object=>c_mode_read ).
            ls_res-checklist = lo_wb->check( ).
            lo_wb->free( ).

          WHEN 'copy'.
            cl_fp_wb_interface=>copy( i_name = lv_name
                                      i_source = CONV fpname( to_upper( ls_req-source ) )
                                      i_devclass = COND devclass( WHEN ls_req-devclass IS INITIAL THEN '$TMP'
                                                                  ELSE to_upper( ls_req-devclass ) )
                                      i_ordernum = lv_tr ).
            APPEND |copied { ls_req-source } to { lv_name }| TO ls_res-messages.

          WHEN 'delete'.
            lo_wb = cl_fp_wb_interface=>load( i_name = lv_name i_mode = if_fp_wb_object=>c_mode_read ).
            IF lo_wb->get_devclass( ) <> '$TMP'.
              lo_wb->free( ).
              APPEND |refusing to delete { lv_name }: package is { lo_wb->get_devclass( ) }, only $TMP objects can be deleted| TO ls_res-messages.
              ls_res-ok = 'false'.
            ELSE.
              lo_wb->free( ).
              cl_fp_wb_interface=>delete( i_name = lv_name ).
              APPEND |deleted { lv_name }| TO ls_res-messages.
            ENDIF.

          WHEN 'create_interface'.
            DATA(lo_ni) = cl_fp_interface=>create( ).
            lo_ni->if_fp_object~set_description( CONV fptext( ls_req-description ) ).
            DATA(lo_wbi) = cl_fp_wb_interface=>create(
              i_name = lv_name i_interface = lo_ni
              i_devclass = COND devclass( WHEN ls_req-devclass IS INITIAL THEN '$TMP' ELSE to_upper( ls_req-devclass ) )
              i_ordernum = lv_tr ).
            lo_wbi->save( ).
            lo_wbi->free( ).
            APPEND |created interface { lv_name }| TO ls_res-messages.

          WHEN 'create_form'.
            DATA(lo_nf) = cl_fp_form=>create( ).
            lo_nf->if_fp_object~set_description( CONV fptext( ls_req-description ) ).
            lo_nf->set_interface_name( CONV fpname( to_upper( ls_req-interface ) ) ).
            IF ls_req-layout IS NOT INITIAL.
              DATA lx_new_layout TYPE xstring.
              CALL FUNCTION 'SCMS_BASE64_DECODE_STR'
                EXPORTING input = ls_req-layout
                IMPORTING output = lx_new_layout
                EXCEPTIONS failed = 1 OTHERS = 2.
              lo_nf->get_layout( )->set_layout_data( i_layout_data = lx_new_layout ).
            ENDIF.
            DATA(lo_wbf) = cl_fp_wb_form=>create(
              i_name = lv_name i_form = lo_nf
              i_devclass = COND devclass( WHEN ls_req-devclass IS INITIAL THEN '$TMP' ELSE to_upper( ls_req-devclass ) )
              i_ordernum = lv_tr ).
            lo_wbf->save( ).
            lo_wbf->free( ).
            APPEND |created form { lv_name } (inactive, run activate)| TO ls_res-messages.

          WHEN 'read_form' OR 'set_layout'.
            DATA lo_wbf2 TYPE REF TO if_fp_wb_form.
            IF ls_req-action = 'set_layout'.
              lo_wbf2 = cl_fp_wb_form=>load( i_name = lv_name i_mode = if_fp_wb_object=>c_mode_write
                                             i_ordernum = lv_tr ).
              DATA lx_set_layout TYPE xstring.
              CALL FUNCTION 'SCMS_BASE64_DECODE_STR'
                EXPORTING input = ls_req-layout
                IMPORTING output = lx_set_layout
                EXCEPTIONS failed = 1 OTHERS = 2.
              CAST if_fp_form( lo_wbf2->get_object( ) )->get_layout( )->set_layout_data( i_layout_data = lx_set_layout ).
              lo_wbf2->save( ).
              lo_wbf2->free( ).
              APPEND 'layout saved (inactive version); run activate' TO ls_res-messages.
            ENDIF.
            lo_wbf2 = cl_fp_wb_form=>load( i_name = lv_name i_mode = if_fp_wb_object=>c_mode_read ).
            DATA(lo_fm) = CAST if_fp_form( lo_wbf2->get_object( ) ).
            ls_res-description = lo_fm->if_fp_object~get_description( ).
            ls_res-interface = lo_fm->get_interface_name( ).
            ls_res-state = lo_wbf2->get_state( ).
            ls_res-devclass = lo_wbf2->get_devclass( ).
            ls_res-ordernum = lo_wbf2->get_ordernum( ).
            DATA(lo_lay) = lo_fm->get_layout( ).
            ls_res-layout_type = lo_lay->get_layout_type( ).
            ls_res-form_tech = lo_lay->get_form_tech( ).
            IF ls_req-with_layout = 'X' OR ls_req-action = 'set_layout'.
              DATA(lx_layout_out) = lo_lay->get_layout_data( ).
              CALL FUNCTION 'SCMS_BASE64_ENCODE_STR'
                EXPORTING input = lx_layout_out
                IMPORTING output = ls_res-layout.
            ENDIF.
            lo_wbf2->free( ).

          WHEN 'delete_form'.
            DATA(lo_wbf3) = cl_fp_wb_form=>load( i_name = lv_name i_mode = if_fp_wb_object=>c_mode_read ).
            IF lo_wbf3->get_devclass( ) <> '$TMP'.
              APPEND |refusing to delete { lv_name }: package is { lo_wbf3->get_devclass( ) }, only $TMP objects can be deleted| TO ls_res-messages.
              ls_res-ok = 'false'.
              lo_wbf3->free( ).
            ELSE.
              lo_wbf3->free( ).
              cl_fp_wb_form=>delete( i_name = lv_name ).
              APPEND |deleted form { lv_name }| TO ls_res-messages.
            ENDIF.

          WHEN 'query'.
            DATA lr_q TYPE REF TO data.
            FIELD-SYMBOLS <lt_q> TYPE STANDARD TABLE.
            DATA lv_qtab TYPE tabname.
            lv_qtab = lv_name.
            DATA(lv_qcols) = to_upper( ls_req-columns ).
            IF lv_qcols CS 'BCODE' OR lv_qcols CS 'PASSCODE' OR lv_qcols CS 'HASH' OR lv_qcols CS 'PWD_'.
              APPEND 'refusing to read password-related columns' TO ls_res-messages.
              ls_res-ok = 'false'.
            ELSEIF lv_qtab = 'USR02' AND lv_qcols IS INITIAL.
              APPEND 'USR02 needs an explicit column list (status fields only)' TO ls_res-messages.
              ls_res-ok = 'false'.
            ELSE.
              CREATE DATA lr_q TYPE STANDARD TABLE OF (lv_qtab).
              ASSIGN lr_q->* TO <lt_q>.
              DATA(lv_qmax) = COND i( WHEN ls_req-max_rows > 0 THEN ls_req-max_rows ELSE 50 ).
              DATA(lv_qsel) = COND string( WHEN lv_qcols IS INITIAL THEN `*` ELSE lv_qcols ).
              IF ls_req-client_specified = 'X'.
                SELECT (lv_qsel) FROM (lv_qtab) CLIENT SPECIFIED UP TO @lv_qmax ROWS
                  INTO CORRESPONDING FIELDS OF TABLE @<lt_q> WHERE (ls_req-where_clause).
              ELSE.
                SELECT (lv_qsel) FROM (lv_qtab) UP TO @lv_qmax ROWS
                  INTO CORRESPONDING FIELDS OF TABLE @<lt_q> WHERE (ls_req-where_clause).
              ENDIF.
              ls_res-total_rows = lines( <lt_q> ).
              ls_res-data = /ui2/cl_json=>serialize( data = <lt_q> compress = abap_true
                                                     pretty_name = /ui2/cl_json=>pretty_mode-none ).
            ENDIF.

          WHEN 'run_report'.
            DATA lt_sel TYPE STANDARD TABLE OF rsparams WITH EMPTY KEY.
            LOOP AT ls_req-sel INTO DATA(ls_sel).
              APPEND VALUE rsparams( selname = to_upper( ls_sel-selname ) kind = to_upper( ls_sel-kind )
                                     sign = ls_sel-sign option = ls_sel-option
                                     low = ls_sel-low high = ls_sel-high ) TO lt_sel.
            ENDLOOP.
            DATA lv_rep TYPE programm.
            lv_rep = lv_name.
            cl_salv_bs_runtime_info=>set( display = abap_false metadata = abap_false data = abap_true ).
            TRY.
                SUBMIT (lv_rep) WITH SELECTION-TABLE lt_sel EXPORTING LIST TO MEMORY AND RETURN.
              CATCH cx_root INTO DATA(lx_sub).
                APPEND |submit error: { lx_sub->get_text( ) }| TO ls_res-messages.
            ENDTRY.
            TRY.
                cl_salv_bs_runtime_info=>get_data_ref( IMPORTING r_data = DATA(lr_alv) ).
                FIELD-SYMBOLS <lt_alv> TYPE STANDARD TABLE.
                FIELD-SYMBOLS <lt_cpy> TYPE STANDARD TABLE.
                FIELD-SYMBOLS <ls_row> TYPE any.
                ASSIGN lr_alv->* TO <lt_alv>.
                ls_res-total_rows = lines( <lt_alv> ).
                DATA lr_cpy TYPE REF TO data.
                CREATE DATA lr_cpy LIKE <lt_alv>.
                ASSIGN lr_cpy->* TO <lt_cpy>.
                DATA(lv_max) = COND i( WHEN ls_req-max_rows > 0 THEN ls_req-max_rows ELSE 100 ).
                LOOP AT <lt_alv> ASSIGNING <ls_row> FROM 1 TO lv_max.
                  APPEND <ls_row> TO <lt_cpy>.
                ENDLOOP.
                ls_res-data = /ui2/cl_json=>serialize( data = <lt_cpy> compress = abap_true
                                                       pretty_name = /ui2/cl_json=>pretty_mode-none ).
              CATCH cx_root INTO DATA(lx_alv).
                APPEND |no ALV data captured: { lx_alv->get_text( ) }| TO ls_res-messages.
            ENDTRY.
            cl_salv_bs_runtime_info=>clear_all( ).
            DATA lt_list TYPE STANDARD TABLE OF abaplist WITH EMPTY KEY.
            CALL FUNCTION 'LIST_FROM_MEMORY'
              TABLES listobject = lt_list
              EXCEPTIONS not_found = 1 OTHERS = 2.
            IF sy-subrc = 0 AND lt_list IS NOT INITIAL.
              DATA lt_asci TYPE STANDARD TABLE OF char2048 WITH EMPTY KEY.
              CALL FUNCTION 'LIST_TO_ASCI'
                TABLES listasci = lt_asci listobject = lt_list
                EXCEPTIONS empty_list = 1 list_index_invalid = 2 OTHERS = 3.
              LOOP AT lt_asci INTO DATA(lv_asci) FROM 1 TO 200.
                APPEND CONV string( lv_asci ) TO ls_res-list.
              ENDLOOP.
            ENDIF.

          WHEN 'render_form'.
            DATA(lo_rwb) = cl_fp_wb_form=>load( i_name = lv_name i_mode = if_fp_wb_object=>c_mode_read ).
            DATA(lo_rform) = CAST if_fp_form( lo_rwb->get_object( ) ).
            DATA(lv_if_name) = lo_rform->get_interface_name( ).
            lo_rwb->free( ).
            DATA(lo_rwi) = cl_fp_wb_interface=>load( i_name = lv_if_name i_mode = if_fp_wb_object=>c_mode_read ).
            DATA(lt_ipar) = CAST if_fp_interface( lo_rwi->get_object( ) )->get_interface_data( )->get_parameters( )->get_import_parameters( ).
            lo_rwi->free( ).
            DATA lv_fm TYPE rs38l_fnam.
            CALL FUNCTION 'FP_FUNCTION_MODULE_NAME'
              EXPORTING i_name = CONV fpname( lv_name )
              IMPORTING e_funcname = lv_fm.
            ls_res-fm = lv_fm.
            DATA lt_ptab TYPE abap_func_parmbind_tab.
            DATA lt_keep TYPE STANDARD TABLE OF REF TO data WITH EMPTY KEY.
            LOOP AT lt_ipar INTO DATA(ls_ipar).
              READ TABLE ls_req-params INTO DATA(ls_prm) WITH KEY name = ls_ipar-name.
              IF sy-subrc <> 0.
                CONTINUE.
              ENDIF.
              DATA lr_val TYPE REF TO data.
              CREATE DATA lr_val TYPE (ls_ipar-typename).
              ASSIGN lr_val->* TO FIELD-SYMBOL(<lv_val>).
              IF ls_prm-value CP '@SIG:*'.
                FIELD-SYMBOLS <lt_sig> TYPE STANDARD TABLE.
                ASSIGN lr_val->* TO <lt_sig>.
                CALL FUNCTION 'ZHR_FM_GET_SIGNATURES'
                  EXPORTING iv_type = CONV zreq_type( ls_prm-value+5 )
                  TABLES et_data = <lt_sig>.
              ELSE.
                /ui2/cl_json=>deserialize( EXPORTING json = ls_prm-value
                                                     pretty_name = /ui2/cl_json=>pretty_mode-none
                                           CHANGING data = <lv_val> ).
              ENDIF.
              APPEND lr_val TO lt_keep.
              INSERT VALUE abap_func_parmbind( name = ls_ipar-name kind = abap_func_exporting value = lr_val ) INTO TABLE lt_ptab.
            ENDLOOP.
            DATA ls_docp TYPE sfpdocparams.
            DATA ls_fout TYPE fpformoutput.
            INSERT VALUE abap_func_parmbind( name = '/1BCDWB/DOCPARAMS' kind = abap_func_exporting value = REF #( ls_docp ) ) INTO TABLE lt_ptab.
            INSERT VALUE abap_func_parmbind( name = '/1BCDWB/FORMOUTPUT' kind = abap_func_importing value = REF #( ls_fout ) ) INTO TABLE lt_ptab.
            DATA ls_outp TYPE sfpoutputparams.
            ls_outp-getpdf = 'X'.
            ls_outp-nodialog = 'X'.
            ls_outp-dest = 'LP01'.
            CALL FUNCTION 'FP_JOB_OPEN'
              CHANGING ie_outputparams = ls_outp
              EXCEPTIONS cancel = 1 usage_error = 2 system_error = 3 internal_error = 4 OTHERS = 5.
            IF sy-subrc <> 0.
              APPEND |FP_JOB_OPEN failed rc={ sy-subrc }| TO ls_res-messages.
              ls_res-ok = 'false'.
            ELSE.
              DATA lt_etab TYPE abap_func_excpbind_tab.
              lt_etab = VALUE #( ( name = 'USAGE_ERROR' value = 1 ) ( name = 'SYSTEM_ERROR' value = 2 )
                                 ( name = 'INTERNAL_ERROR' value = 3 ) ( name = 'OTHERS' value = 4 ) ).
              CALL FUNCTION lv_fm PARAMETER-TABLE lt_ptab EXCEPTION-TABLE lt_etab.
              IF sy-subrc <> 0.
                MESSAGE ID sy-msgid TYPE 'S' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO DATA(lv_fmsg).
                APPEND |form call failed rc={ sy-subrc }: { lv_fmsg }| TO ls_res-messages.
                ls_res-ok = 'false'.
              ENDIF.
              CALL FUNCTION 'FP_JOB_CLOSE' EXCEPTIONS OTHERS = 1.
              IF ls_fout-pdf IS NOT INITIAL.
                CALL FUNCTION 'SCMS_BASE64_ENCODE_STR'
                  EXPORTING input = ls_fout-pdf
                  IMPORTING output = ls_res-pdf.
              ENDIF.
            ENDIF.

          WHEN OTHERS.
            APPEND |unknown action { ls_req-action }| TO ls_res-messages.
        ENDCASE.
        IF ls_res-ok IS INITIAL.
          ls_res-ok = 'true'.
        ENDIF.
      CATCH cx_root INTO DATA(lx).
        ls_res-ok = 'false'.
        APPEND |{ cl_abap_classdescr=>describe_by_object_ref( lx )->get_relative_name( ) }: { lx->get_text( ) }| TO ls_res-messages.
    ENDTRY.

    DATA(lv_out) = /ui2/cl_json=>serialize( data = ls_res compress = abap_false
                                            pretty_name = /ui2/cl_json=>pretty_mode-low_case ).
    out->write( |<<<JSON{ cl_abap_char_utilities=>newline }{ lv_out }{ cl_abap_char_utilities=>newline }JSON>>>| ).
  ENDMETHOD.

ENDCLASS.
