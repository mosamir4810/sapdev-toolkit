CLASS zcl_rest_ping DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_http_extension.
ENDCLASS.

CLASS zcl_rest_ping IMPLEMENTATION.
  METHOD if_http_extension~handle_request.
    DATA(lv_method) = server->request->get_header_field( '~request_method' ).
    DATA(lv_name) = server->request->get_form_field( 'name' ).
    IF lv_name IS INITIAL.
      lv_name = 'world'.
    ENDIF.
    server->response->set_header_field( name = 'Content-Type' value = 'application/json; charset=utf-8' ).
    server->response->set_cdata( |\{"message":"hello { lv_name }","method":"{ lv_method }","user":"{ sy-uname }","time":"{ sy-datum }{ sy-uzeit }"\}| ).
    server->response->set_status( code = 200 reason = 'OK' ).
  ENDMETHOD.
ENDCLASS.
