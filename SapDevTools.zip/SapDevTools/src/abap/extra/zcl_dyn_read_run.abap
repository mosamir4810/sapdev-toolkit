CLASS zcl_dyn_read_run DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
  PRIVATE SECTION.
    DATA mt_out TYPE string_table.
    METHODS row IMPORTING iv_tag TYPE string is_row TYPE any.
    METHODS dump IMPORTING iv_prog TYPE progname.
ENDCLASS.
CLASS zcl_dyn_read_run IMPLEMENTATION.
  METHOD row.
    DATA: lv_s TYPE string, lv_v TYPE string.
    FIELD-SYMBOLS <c> TYPE any.
    lv_s = iv_tag.
    DATA(lo) = CAST cl_abap_structdescr( cl_abap_typedescr=>describe_by_data( is_row ) ).
    LOOP AT lo->components INTO DATA(ls_c).
      ASSIGN COMPONENT ls_c-name OF STRUCTURE is_row TO <c>.
      IF sy-subrc = 0 AND <c> IS NOT INITIAL.
        lv_v = <c>.
        lv_s = |{ lv_s }~{ ls_c-name }={ lv_v }|.
      ENDIF.
    ENDLOOP.
    APPEND lv_s TO mt_out.
  ENDMETHOD.
  METHOD dump.
    DATA: lt_tp TYPE STANDARD TABLE OF textpool,
          lt_lang TYPE STANDARD TABLE OF d010tinf-language,
          ls_adm TYPE rsmpe_adm,
          lt_sta TYPE STANDARD TABLE OF rsmpe_stat, lt_fun TYPE STANDARD TABLE OF rsmpe_funt,
          lt_men TYPE STANDARD TABLE OF rsmpe_men, lt_mtx TYPE STANDARD TABLE OF rsmpe_mnlt,
          lt_act TYPE STANDARD TABLE OF rsmpe_act, lt_but TYPE STANDARD TABLE OF rsmpe_but,
          lt_pfk TYPE STANDARD TABLE OF rsmpe_pfk, lt_set TYPE STANDARD TABLE OF rsmpe_staf,
          lt_doc TYPE STANDARD TABLE OF rsmpe_atrt, lt_tit TYPE STANDARD TABLE OF rsmpe_titt,
          lt_biv TYPE STANDARD TABLE OF rsmpe_buts.
    SELECT language FROM d010tinf WHERE prog = @iv_prog INTO TABLE @lt_lang.
    LOOP AT lt_lang INTO DATA(lv_l).
      READ TEXTPOOL iv_prog INTO lt_tp LANGUAGE lv_l.
      LOOP AT lt_tp INTO DATA(ls_tp).
        APPEND |TP~{ iv_prog }~{ lv_l }~{ ls_tp-id }~{ ls_tp-key }~{ ls_tp-entry }~{ ls_tp-length }| TO mt_out.
      ENDLOOP.
    ENDLOOP.
    CALL FUNCTION 'RS_CUA_INTERNAL_FETCH'
      EXPORTING program = iv_prog language = 'E' state = 'A'
      IMPORTING adm = ls_adm
      TABLES sta = lt_sta fun = lt_fun men = lt_men mtx = lt_mtx act = lt_act but = lt_but
             pfk = lt_pfk set = lt_set doc = lt_doc tit = lt_tit biv = lt_biv
      EXCEPTIONS OTHERS = 1.
    APPEND |CUA~{ iv_prog } rc={ sy-subrc } sta={ lines( lt_sta ) } fun={ lines( lt_fun ) } men={ lines( lt_men ) } but={ lines( lt_but ) } pfk={ lines( lt_pfk ) } set={ lines( lt_set ) } tit={ lines( lt_tit ) }| TO mt_out.
    row( iv_tag = `ADM` is_row = ls_adm ).
    LOOP AT lt_sta INTO DATA(a1). row( iv_tag = `STA` is_row = a1 ). ENDLOOP.
    LOOP AT lt_fun INTO DATA(a2). row( iv_tag = `FUN` is_row = a2 ). ENDLOOP.
    LOOP AT lt_men INTO DATA(a3). row( iv_tag = `MEN` is_row = a3 ). ENDLOOP.
    LOOP AT lt_mtx INTO DATA(a4). row( iv_tag = `MTX` is_row = a4 ). ENDLOOP.
    LOOP AT lt_act INTO DATA(a5). row( iv_tag = `ACT` is_row = a5 ). ENDLOOP.
    LOOP AT lt_but INTO DATA(a6). row( iv_tag = `BUT` is_row = a6 ). ENDLOOP.
    LOOP AT lt_pfk INTO DATA(a7). row( iv_tag = `PFK` is_row = a7 ). ENDLOOP.
    LOOP AT lt_set INTO DATA(a8). row( iv_tag = `SET` is_row = a8 ). ENDLOOP.
    LOOP AT lt_doc INTO DATA(a9). row( iv_tag = `DOC` is_row = a9 ). ENDLOOP.
    LOOP AT lt_tit INTO DATA(a10). row( iv_tag = `TIT` is_row = a10 ). ENDLOOP.
    LOOP AT lt_biv INTO DATA(a11). row( iv_tag = `BIV` is_row = a11 ). ENDLOOP.
  ENDMETHOD.
  METHOD if_oo_adt_classrun~main.
    dump( 'ZHRR0001' ).
    LOOP AT mt_out INTO DATA(lv_l).
      out->write( lv_l ).
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
