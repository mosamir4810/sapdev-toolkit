CLASS zcl_sdt_wf DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
  PRIVATE SECTION.
    DATA mo_out TYPE REF TO if_oo_adt_classrun_out.
    METHODS row IMPORTING iv_tag TYPE string is_row TYPE any.
    METHODS export_def IMPORTING iv_id TYPE swd_wfd_id iv_ver TYPE swd_versio iv_exe TYPE swd_exetyp.
    METHODS activate_def IMPORTING iv_id TYPE swd_wfd_id iv_ver TYPE swd_versio iv_exe TYPE swd_exetyp.
    METHODS copy_def IMPORTING iv_id TYPE swd_wfd_id iv_ver TYPE swd_versio iv_new TYPE swd_wfd_id.
ENDCLASS.

CLASS zcl_sdt_wf IMPLEMENTATION.
  METHOD row.
    DATA: lv_s TYPE string, lv_v TYPE string.
    FIELD-SYMBOLS <c> TYPE any.
    lv_s = iv_tag.
    DATA(lo) = CAST cl_abap_structdescr( cl_abap_typedescr=>describe_by_data( is_row ) ).
    LOOP AT lo->components INTO DATA(ls_c).
      ASSIGN COMPONENT ls_c-name OF STRUCTURE is_row TO <c>.
      IF sy-subrc = 0 AND <c> IS NOT INITIAL.
        lv_v = <c>.
        lv_s = |{ lv_s }~{ ls_c-name }={ lv_v }|.
      ENDIF.
    ENDLOOP.
    mo_out->write( lv_s ).
  ENDMETHOD.

  METHOD export_def.
    DATA: ls_key  TYPE swd_wfdkey,
          ls_head TYPE swd_shead,
          lt_steps TYPE STANDARD TABLE OF swd_ssteps,
          lt_nodes TYPE STANDARD TABLE OF swd_snodes,
          lt_lines TYPE STANDARD TABLE OF swd_slines,
          lt_bind  TYPE STANDARD TABLE OF swd_sbind,
          lt_cond  TYPE STANDARD TABLE OF swd_condef,
          lt_meth  TYPE STANDARD TABLE OF swd_smetho,
          lt_evnt  TYPE STANDARD TABLE OF swd_sevnts,
          lt_func  TYPE STANDARD TABLE OF swd_sfuncs.
    ls_key = VALUE #( wfd_id = iv_id version = iv_ver exetyp = iv_exe ).
    CALL FUNCTION 'SWD_WF_DEFINITION_READ'
      EXPORTING task = CONV swd_ahead-task( iv_id ) wfdkey = ls_key refresh_buffer = 'X'
      IMPORTING header = ls_head
      TABLES steps = lt_steps nodes = lt_nodes lines = lt_lines bindings = lt_bind
             conditions = lt_cond methods = lt_meth events = lt_evnt functions = lt_func
      EXCEPTIONS definition_not_found = 1 OTHERS = 2.
    IF sy-subrc <> 0.
      mo_out->write( |NOT_FOUND~{ iv_id }~{ iv_ver }~{ iv_exe }| ).
      RETURN.
    ENDIF.
    row( iv_tag = `HEADER` is_row = ls_head ).
    LOOP AT lt_steps INTO DATA(s1). row( iv_tag = `STEP` is_row = s1 ). ENDLOOP.
    LOOP AT lt_nodes INTO DATA(s2). row( iv_tag = `NODE` is_row = s2 ). ENDLOOP.
    LOOP AT lt_lines INTO DATA(s3). row( iv_tag = `LINE` is_row = s3 ). ENDLOOP.
    LOOP AT lt_bind INTO DATA(s4). row( iv_tag = `BIND` is_row = s4 ). ENDLOOP.
    LOOP AT lt_cond INTO DATA(s5). row( iv_tag = `COND` is_row = s5 ). ENDLOOP.
    LOOP AT lt_meth INTO DATA(s6). row( iv_tag = `METH` is_row = s6 ). ENDLOOP.
    LOOP AT lt_evnt INTO DATA(s7). row( iv_tag = `EVNT` is_row = s7 ). ENDLOOP.
    LOOP AT lt_func INTO DATA(s8). row( iv_tag = `FUNC` is_row = s8 ). ENDLOOP.
    mo_out->write( |SUMMARY steps={ lines( lt_steps ) } nodes={ lines( lt_nodes ) } lines={ lines( lt_lines ) }| &&
                   | bindings={ lines( lt_bind ) } conditions={ lines( lt_cond ) } methods={ lines( lt_meth ) }| &&
                   | events={ lines( lt_evnt ) } functions={ lines( lt_func ) }| ).
  ENDMETHOD.

  METHOD activate_def.
    " EXPERIMENTAL: standard activation of an existing definition
    DATA: ls_key TYPE swd_wfdkey, lv_cnt TYPE sy-tabix, lv_ty TYPE sy-msgty.
    ls_key = VALUE #( wfd_id = iv_id version = iv_ver exetyp = iv_exe ).
    CALL FUNCTION 'SWD_WF_DEFINITION_ACTIVATE'
      EXPORTING act_task = CONV swd_ahead-task( iv_id ) act_wfdkey = ls_key do_commit = 'X'
      IMPORTING error_count = lv_cnt worst_messagetype = lv_ty
      EXCEPTIONS OTHERS = 1.
    mo_out->write( |ACTIVATE rc={ sy-subrc } errors={ lv_cnt } worst={ lv_ty }| ).
  ENDMETHOD.

  METHOD copy_def.
    " EXPERIMENTAL: copy a workflow definition to a new id with the standard copy function
    DATA: lv_new TYPE swd_wfdkey-wfd_id, lv_ver TYPE swd_wfdkey-version, lv_act TYPE swd_data-xfeld.
    CALL FUNCTION 'SWD_WF_DEFINITION_COPY'
      EXPORTING
        target_otype = 'WS' target_objid = CONV hrobjid( iv_new+2 ) target_wfd_id = iv_new
        source_otype = 'WS' source_objid = CONV hrobjid( iv_id+2 ) source_wfd_id = iv_id
        source_wfd_version = iv_ver
      IMPORTING new_wfd_id = lv_new new_wfd_version = lv_ver new_wfd_activ = lv_act
      EXCEPTIONS OTHERS = 1.
    IF sy-subrc = 0.
      COMMIT WORK.
    ENDIF.
    mo_out->write( |COPY rc={ sy-subrc } new={ lv_new } version={ lv_ver } active={ lv_act } { sy-msgid }{ sy-msgno }| ).
  ENDMETHOD.

  METHOD if_oo_adt_classrun~main.
    mo_out = out.
    CASE '{{ACTION}}'.
      WHEN 'export'.   export_def( iv_id = '{{WFD_ID}}' iv_ver = '{{VERSION}}' iv_exe = '{{EXETYP}}' ).
      WHEN 'activate'. activate_def( iv_id = '{{WFD_ID}}' iv_ver = '{{VERSION}}' iv_exe = '{{EXETYP}}' ).
      WHEN 'copy'.     copy_def( iv_id = '{{WFD_ID}}' iv_ver = '{{VERSION}}' iv_new = '{{TARGET_ID}}' ).
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
