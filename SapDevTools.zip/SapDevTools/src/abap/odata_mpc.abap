CLASS {{MPC}} DEFINITION PUBLIC INHERITING FROM /iwbep/cl_mgw_push_abs_model FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS define REDEFINITION.
ENDCLASS.

CLASS {{MPC}} IMPLEMENTATION.
  METHOD define.
    " Entity {{ENTITY}} bound to DDIC structure/table {{TABLE}}, entity set {{SET}} (read-only)
    DATA: lo_type TYPE REF TO /iwbep/if_mgw_odata_entity_typ,
          lo_prop TYPE REF TO /iwbep/if_mgw_odata_property,
          lo_set  TYPE REF TO /iwbep/if_mgw_odata_entity_set.
    model->set_schema_namespace( 'ZSDT' ).
    lo_type = model->create_entity_type( iv_entity_type_name = '{{ENTITY}}' iv_def_entity_set = abap_false ).
    lo_type->bind_structure( iv_structure_name = '{{TABLE}}' iv_bind_conversions = abap_false ).
    SELECT fieldname FROM dd03l WHERE tabname = '{{TABLE}}' AND as4local = 'A' AND keyflag = 'X'
      AND fieldname NOT LIKE '.%' INTO TABLE @DATA(lt_keys).
    LOOP AT lt_keys INTO DATA(ls_key).
      TRY.
          lo_prop = lo_type->get_property( CONV #( ls_key-fieldname ) ).
          lo_prop->set_is_key( ).
        CATCH cx_root.
      ENDTRY.
    ENDLOOP.
    lo_set = lo_type->create_entity_set( '{{SET}}' ).
    lo_set->set_creatable( abap_false ).
    lo_set->set_updatable( abap_false ).
    lo_set->set_deletable( abap_false ).
  ENDMETHOD.
ENDCLASS.
