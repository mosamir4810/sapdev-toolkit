CLASS {{DPC}} DEFINITION PUBLIC INHERITING FROM /iwbep/cl_mgw_push_abs_data CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS /iwbep/if_mgw_appl_srv_runtime~get_entityset REDEFINITION.
    METHODS /iwbep/if_mgw_appl_srv_runtime~get_entity REDEFINITION.
  PROTECTED SECTION.
    METHODS check_subscription_authority REDEFINITION.
ENDCLASS.

CLASS {{DPC}} IMPLEMENTATION.
  METHOD /iwbep/if_mgw_appl_srv_runtime~get_entityset.
    " Read-only set over {{TABLE}}: supports $filter, $top, $skip, $inlinecount
    CONSTANTS lc_table TYPE tabname VALUE '{{TABLE}}'.
    DATA: lr TYPE REF TO data, lv_where TYPE string, lv_up TYPE i.
    FIELD-SYMBOLS <lt> TYPE STANDARD TABLE.
    AUTHORITY-CHECK OBJECT 'S_TABU_NAM' ID 'ACTVT' FIELD '03' ID 'TABLE' FIELD lc_table.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING textid = /iwbep/cx_mgw_busi_exception=>business_error
                  message_unlimited = |Not authorized for { lc_table }|.
    ENDIF.
    CREATE DATA lr TYPE STANDARD TABLE OF (lc_table) WITH EMPTY KEY.
    ASSIGN lr->* TO <lt>.
    lv_where = io_tech_request_context->get_osql_where_clause_convert( ).
    lv_up = COND #( WHEN is_paging-top > 0 THEN is_paging-top + is_paging-skip ELSE 0 ).
    IF lv_up > 0.
      SELECT * FROM (lc_table) WHERE (lv_where) INTO TABLE @<lt> UP TO @lv_up ROWS.
    ELSE.
      SELECT * FROM (lc_table) WHERE (lv_where) INTO TABLE @<lt>.
    ENDIF.
    IF io_tech_request_context->has_inlinecount( ) = abap_true.
      es_response_context-inlinecount = lines( <lt> ).
    ENDIF.
    IF is_paging-skip > 0.
      DELETE <lt> FROM 1 TO nmin( val1 = is_paging-skip val2 = lines( <lt> ) ).
    ENDIF.
    er_entityset = lr.
  ENDMETHOD.

  METHOD /iwbep/if_mgw_appl_srv_runtime~get_entity.
    CONSTANTS lc_table TYPE tabname VALUE '{{TABLE}}'.
    DATA: lr TYPE REF TO data, lv_where TYPE string.
    FIELD-SYMBOLS <ls> TYPE any.
    AUTHORITY-CHECK OBJECT 'S_TABU_NAM' ID 'ACTVT' FIELD '03' ID 'TABLE' FIELD lc_table.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING textid = /iwbep/cx_mgw_busi_exception=>business_error
                  message_unlimited = |Not authorized for { lc_table }|.
    ENDIF.
    LOOP AT it_key_tab INTO DATA(ls_key).
      DATA(lv_val) = replace( val = ls_key-value sub = `'` with = `''` occ = 0 ).
      lv_where = COND #( WHEN lv_where IS INITIAL THEN |{ to_upper( ls_key-name ) } = '{ lv_val }'|
                         ELSE |{ lv_where } AND { to_upper( ls_key-name ) } = '{ lv_val }'| ).
    ENDLOOP.
    CREATE DATA lr TYPE (lc_table).
    ASSIGN lr->* TO <ls>.
    SELECT SINGLE * FROM (lc_table) WHERE (lv_where) INTO @<ls>.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
        EXPORTING textid = /iwbep/cx_mgw_busi_exception=>resource_not_found.
    ENDIF.
    er_entity = lr.
  ENDMETHOD.

  METHOD check_subscription_authority.
    " push subscriptions are not supported by this read-only service
    RAISE EXCEPTION TYPE /iwbep/cx_mgw_not_impl_exc
      EXPORTING textid = /iwbep/cx_mgw_not_impl_exc=>method_not_implemented
                method = 'CHECK_SUBSCRIPTION_AUTHORITY'.
  ENDMETHOD.
ENDCLASS.
