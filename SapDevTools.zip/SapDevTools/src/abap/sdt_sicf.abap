CLASS zcl_sdt_sicf DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
  PRIVATE SECTION.
    METHODS find_node IMPORTING iv_path TYPE string RETURNING VALUE(rv_guid) TYPE icfnodguid.
ENDCLASS.

CLASS zcl_sdt_sicf IMPLEMENTATION.
  METHOD find_node.
    " walks /a/b/c from the SICF root (names are stored in upper case)
    DATA lv_cur TYPE icfnodguid VALUE '0000000000000000000000000'.
    SPLIT iv_path AT '/' INTO TABLE DATA(lt_parts).
    DELETE lt_parts WHERE table_line IS INITIAL.
    LOOP AT lt_parts INTO DATA(lv_part).
      DATA(lv_name) = to_upper( lv_part ).
      SELECT SINGLE icfnodguid FROM icfservice WHERE icf_name = @lv_name AND icfparguid = @lv_cur INTO @DATA(lv_g).
      IF sy-subrc <> 0.
        CLEAR rv_guid.
        RETURN.
      ENDIF.
      lv_cur = lv_g.
    ENDLOOP.
    IF lt_parts IS INITIAL.
      rv_guid = lv_cur.
      RETURN.
    ENDIF.
    rv_guid = lv_cur.
  ENDMETHOD.

  METHOD if_oo_adt_classrun~main.
    DATA: lv_new TYPE icfnodguid, lt_hand TYPE icfhndlist.
    CASE '{{ACTION}}'.
      WHEN 'info'.
        DATA(lv_g) = find_node( '{{PARENT}}' ).
        out->write( |node '{{PARENT}}' guid={ lv_g }| ).
      WHEN 'create'.
        DATA(lv_par) = find_node( '{{PARENT}}' ).
        IF lv_par IS INITIAL AND '{{PARENT}}' <> '/'.
          out->write( |parent '{{PARENT}}' not found| ).
          RETURN.
        ENDIF.
        DATA(ls_docu) = VALUE icfdocu( icf_name = '{{NAME}}' icf_langu = sy-langu icf_docu = '{{DESCR}}' ).
        APPEND INITIAL LINE TO lt_hand ASSIGNING FIELD-SYMBOL(<h>).
        <h> = '{{HANDLER}}'.
        DATA(lo_tree) = NEW cl_icf_tree( ).
        DATA lv_active TYPE icfactive VALUE 'X'.
        lo_tree->if_icf_tree~insert_node(
          EXPORTING icf_name = CONV icfname( '{{NAME}}' ) icfparguid = lv_par icfdocu = ls_docu
                    icfhandlst = lt_hand icfactive = lv_active icfserdesc = VALUE #( )
                    application = CONV akhkompo( '{{APPL}}' )
          IMPORTING icfnodguid = lv_new
          EXCEPTIONS OTHERS = 1 ).
        out->write( |create rc={ sy-subrc } guid={ lv_new } msg={ sy-msgid }{ sy-msgno } { sy-msgv1 }| ).
        IF sy-subrc = 0.
          COMMIT WORK.
        ENDIF.
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
