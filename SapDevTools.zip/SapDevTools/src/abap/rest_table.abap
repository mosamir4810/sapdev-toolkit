CLASS {{CLASS_NAME}} DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_http_extension.
  PRIVATE SECTION.
    METHODS fail IMPORTING server TYPE REF TO if_http_server iv_code TYPE i iv_text TYPE string.
ENDCLASS.

CLASS {{CLASS_NAME}} IMPLEMENTATION.
  METHOD fail.
    server->response->set_header_field( name = 'Content-Type' value = 'application/json; charset=utf-8' ).
    server->response->set_cdata( |\{"error":"{ iv_text }"\}| ).
    server->response->set_status( code = iv_code reason = iv_text ).
  ENDMETHOD.

  METHOD if_http_extension~handle_request.
    " Read-only JSON service over table/view {{TABLE}}: GET ?<field>=<value>&top=<n>
    CONSTANTS lc_table TYPE tabname VALUE '{{TABLE}}'.
    DATA: lr_data TYPE REF TO data, lv_where TYPE string, lv_top TYPE i VALUE {{MAX_ROWS}}.
    FIELD-SYMBOLS <lt> TYPE STANDARD TABLE.
    DATA(lv_method) = server->request->get_header_field( '~request_method' ).
    IF lv_method <> 'GET'.
      fail( server = server iv_code = 405 iv_text = `Method not allowed` ).
      RETURN.
    ENDIF.
    AUTHORITY-CHECK OBJECT 'S_TABU_NAM' ID 'ACTVT' FIELD '03' ID 'TABLE' FIELD lc_table.
    IF sy-subrc <> 0.
      fail( server = server iv_code = 403 iv_text = `Not authorized for table` ).
      RETURN.
    ENDIF.
    DATA(lv_t) = server->request->get_form_field( 'top' ).
    IF lv_t IS NOT INITIAL AND lv_t CO '0123456789'.
      lv_top = nmin( val1 = CONV i( lv_t ) val2 = lv_top ).
    ENDIF.
    DATA(lo_td) = CAST cl_abap_structdescr( cl_abap_typedescr=>describe_by_name( lc_table ) ).
    LOOP AT lo_td->components INTO DATA(ls_c).
      DATA(lv_val) = server->request->get_form_field( to_lower( ls_c-name ) ).
      IF lv_val IS NOT INITIAL.
        DATA(lv_esc) = replace( val = lv_val sub = `'` with = `''` occ = 0 ).
        lv_where = COND #( WHEN lv_where IS INITIAL THEN |{ ls_c-name } = '{ lv_esc }'| ELSE |{ lv_where } AND { ls_c-name } = '{ lv_esc }'| ).
      ENDIF.
    ENDLOOP.
    CREATE DATA lr_data TYPE STANDARD TABLE OF (lc_table) WITH EMPTY KEY.
    ASSIGN lr_data->* TO <lt>.
    TRY.
        SELECT * FROM (lc_table) WHERE (lv_where) INTO TABLE @<lt> UP TO @lv_top ROWS.
      CATCH cx_sy_dynamic_osql_error INTO DATA(lx).
        fail( server = server iv_code = 400 iv_text = `Invalid filter` ).
        RETURN.
    ENDTRY.
    server->response->set_header_field( name = 'Content-Type' value = 'application/json; charset=utf-8' ).
    server->response->set_cdata( /ui2/cl_json=>serialize( data = <lt> pretty_name = /ui2/cl_json=>pretty_mode-low_case ) ).
    server->response->set_status( code = 200 reason = 'OK' ).
  ENDMETHOD.
ENDCLASS.
